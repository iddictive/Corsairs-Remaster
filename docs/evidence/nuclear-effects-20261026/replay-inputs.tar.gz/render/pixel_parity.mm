#import <Cocoa/Cocoa.h>
#include <cstdio>
#include <algorithm>
int main(int argc,char**argv){@autoreleasepool{
 auto a=[NSBitmapImageRep imageRepWithData:[NSData dataWithContentsOfFile:@(argv[1])]];
 auto b=[NSBitmapImageRep imageRepWithData:[NSData dataWithContentsOfFile:@(argv[2])]];
 if(!a||!b||a.pixelsWide!=b.pixelsWide||a.pixelsHigh!=b.pixelsHigh||a.samplesPerPixel!=b.samplesPerPixel)return 2;
 unsigned changed=0,maxDelta=0;unsigned long long sum=0;
 for(NSInteger y=0;y<a.pixelsHigh;++y)for(NSInteger x=0;x<a.pixelsWide;++x){bool different=false;
  for(unsigned c=0;c<3;++c){auto delta=unsigned(std::abs(int(a.bitmapData[y*a.bytesPerRow+x*a.samplesPerPixel+c])-int(b.bitmapData[y*b.bytesPerRow+x*b.samplesPerPixel+c])));different|=delta!=0;maxDelta=std::max(maxDelta,delta);sum+=delta;}changed+=different;}
 printf("pixelsChanged=%u/%ld maxByteDelta=%u meanByteDelta=%.10f\n",changed,long(a.pixelsWide*a.pixelsHigh),maxDelta,double(sum)/(a.pixelsWide*a.pixelsHigh*3));
}}
