#import <Cocoa/Cocoa.h>
#import <Metal/Metal.h>
#include <simd/simd.h>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <stdexcept>
#include "experiments/native-metal/phonk_ordnance_render.hpp"
constexpr unsigned width=960,height=540;
struct DemoCamera {simd_float4x4 viewProjection,inverseViewProjection;simd_float4 eye,viewport,sun,time;};
const char*sceneMSL=R"MSL(
struct DemoCamera {float4x4 viewProjection,inverseViewProjection;float4 eye,viewport,sun,time;};
struct SceneO {float4 p [[position]];};
struct ScenePixel {float4 color [[color(0)]];float depth [[depth(any)]];};
vertex SceneO demo_scene_vs(uint id [[vertex_id]]){float2 q=float2((id<<1)&2,id&2);return {float4(q*float2(2,-2)+float2(-1,1),0,1)};}
float3 demoRay(float2 pixel,constant DemoCamera&c){float2 ndc=pixel/c.viewport.zw*float2(2,-2)+float2(-1,1);float4 p=c.inverseViewProjection*float4(ndc,0,1);return normalize(p.xyz/p.w-c.eye.xyz);}
fragment ScenePixel demo_scene_fs(SceneO o [[stage_in]],constant DemoCamera&c [[buffer(1)]]){
 float3 ray=demoRay(o.p.xy,c),horizon=float3(.40f,.47f,.50f),zenith=float3(.075f,.14f,.22f);
 if(ray.z<-.001f) {
  float distance=(200.f-c.eye.z)/ray.z;float3 p=c.eye.xyz+ray*distance;
  if(distance>0.f && p.x>45.f && p.x<150.f && p.y>0.f && p.y<180.f) {
   float4 clip=c.viewProjection*float4(p,1);
   return {float4(.18f,.15f,.11f,1),clip.z/clip.w};
  }
 }
 float3 sky=mix(horizon,zenith,smoothstep(-.03f,.55f,ray.y));
 float clouds=shipFireTurbulence(ray*7.f+float3(0,1.7f,0));sky+=float3(.045f)*smoothstep(.58f,.78f,clouds)*smoothstep(.06f,.32f,ray.y);
 if(ray.y>=-.0001f)return {float4(sky,1),1};
 float distance=(-.35f-c.eye.y)/ray.y;float3 p=c.eye.xyz+ray*distance;
 float2 wave=p.xz*.16f;float time=c.time.x;
 float a=sin(wave.x*.87f+wave.y*.39f-time*.8f),b=sin(wave.y*1.13f-wave.x*.33f+time*.6f);
 float3 normal=normalize(float3(-a*.14f,1,-b*.12f));float fresnel=pow(1.f-saturate(dot(normal,-ray)),4.f);
 float sheen=pow(max(dot(normal,normalize(-ray+normalize(c.sun.xyz))),0.f),100.f);
 float3 water=mix(float3(.035f,.10f,.13f),horizon*.65f,fresnel)+sheen*float3(.35f,.31f,.21f);
 water+=float3(.025f,.03f,.033f)*(a*.5f+b*.5f);
 float haze=1.f-exp(-distance*.0008f);water=mix(water,horizon,haze);
 float4 clip=c.viewProjection*float4(p,1);float depth=clamp(clip.z/clip.w,0.f,1.f);
 return {float4(water,1),depth};
}
)MSL";
simd_float4x4 lookAt(simd_float3 eye,simd_float3 target){
 auto z=simd_normalize(target-eye),x=simd_normalize(simd_cross(simd_make_float3(0,1,0),z)),y=simd_cross(z,x);
 return (simd_float4x4){{{x.x,y.x,z.x,0},{x.y,y.y,z.y,0},{x.z,y.z,z.z,0},{-simd_dot(x,eye),-simd_dot(y,eye),-simd_dot(z,eye),1}}};
}
simd_float4x4 perspective(){float scale=1.f/std::tan(.72f*.5f),near=.3f,far=32000.f;return (simd_float4x4){{{scale/(float(width)/height),0,0,0},{0,scale,0,0},{0,0,far/(far-near),1},{0,0,-near*far/(far-near),0}}};}
void savePNG(id<MTLTexture>texture,NSString*path){
 NSBitmapImageRep*image=[[NSBitmapImageRep alloc] initWithBitmapDataPlanes:nullptr pixelsWide:width pixelsHigh:height bitsPerSample:8 samplesPerPixel:4 hasAlpha:YES isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bitmapFormat:0 bytesPerRow:width*4 bitsPerPixel:32];
 std::vector<uint8_t>bgra(size_t(width)*height*4);[texture getBytes:bgra.data() bytesPerRow:width*4 fromRegion:MTLRegionMake2D(0,0,width,height) mipmapLevel:0];auto*rgba=image.bitmapData;
 for(size_t i=0;i<bgra.size();i+=4){rgba[i]=bgra[i+2];rgba[i+1]=bgra[i+1];rgba[i+2]=bgra[i];rgba[i+3]=255;}
 NSData*png=[image representationUsingType:NSBitmapImageFileTypePNG properties:@{}];if(![png writeToFile:path atomically:YES])throw std::runtime_error("Cannot save rendered PNG");
}

int main(int argc,char**argv){@autoreleasepool{try{
 auto device=MTLCreateSystemDefaultDevice();auto queue=[device newCommandQueue];NSError *error=nil;
 auto library=[device newLibraryWithSource:@((std::string(storm_metal::shipFireCommonMSL)+sceneMSL).c_str()) options:nil error:&error];if(!library)throw std::runtime_error(error.localizedDescription.UTF8String);
 auto pd=[MTLRenderPipelineDescriptor new];pd.vertexFunction=[library newFunctionWithName:@"demo_scene_vs"];pd.fragmentFunction=[library newFunctionWithName:@"demo_scene_fs"];pd.colorAttachments[0].pixelFormat=MTLPixelFormatBGRA8Unorm;pd.depthAttachmentPixelFormat=MTLPixelFormatDepth32Float;
 auto pipeline=[device newRenderPipelineStateWithDescriptor:pd error:&error];if(!pipeline)throw std::runtime_error(error.localizedDescription.UTF8String);
 auto td=[MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm width:width height:height mipmapped:NO];td.storageMode=MTLStorageModeShared;td.usage=MTLTextureUsageRenderTarget|MTLTextureUsageShaderRead;auto color=[device newTextureWithDescriptor:td];td.pixelFormat=MTLPixelFormatDepth32Float;td.storageMode=MTLStorageModePrivate;auto depth=[device newTextureWithDescriptor:td];
 auto dd=[MTLDepthStencilDescriptor new];dd.depthCompareFunction=MTLCompareFunctionAlways;dd.depthWriteEnabled=YES;auto ds=[device newDepthStencilStateWithDescriptor:dd];
 storm_metal::PhonkNuclearRenderer nuclear;
 for(unsigned camera=0;camera<2;++camera)for(unsigned frame=0;frame<120;++frame){
  float age=(camera?6.8f:.8f)+float(frame)/120.f;
  auto eye=simd_make_float3(camera?float(frame)*.02f:0.f,camera?120.f:35.f,camera?6000.f:650.f);auto view=lookAt(eye,simd_make_float3(0.f,200.f,0.f)),projection=perspective();
  DemoCamera c{};c.viewProjection=simd_mul(projection,view);c.inverseViewProjection=simd_inverse(c.viewProjection);c.eye=simd_make_float4(eye,1);c.viewport={0,0,width,height};c.sun={-.48f,.81f,-.32f,0};c.time.x=age;
  std::vector<double> times;
  for(unsigned repeat=0;repeat<1;repeat++){
   auto command=[queue commandBuffer];auto pass=[MTLRenderPassDescriptor renderPassDescriptor];pass.colorAttachments[0].texture=color;pass.colorAttachments[0].loadAction=MTLLoadActionClear;pass.colorAttachments[0].storeAction=MTLStoreActionStore;pass.depthAttachment.texture=depth;pass.depthAttachment.loadAction=MTLLoadActionClear;pass.depthAttachment.storeAction=MTLStoreActionStore;pass.depthAttachment.clearDepth=1;
   auto encoder=[command renderCommandEncoderWithDescriptor:pass];[encoder setRenderPipelineState:pipeline];[encoder setDepthStencilState:ds];[encoder setFragmentBytes:&c length:sizeof(c) atIndex:1];[encoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];[encoder endEncoding];
   const float center[]={0,0,0};auto rebasedView=lookAt(simd_make_float3(0.f,0.f,0.f),simd_make_float3(0.f,200.f,0.f)-eye);if(!nuclear.encode(device,command,color,depth,rebasedView,projection,-eye,{0,0,width,height},center,220.f*std::strtof(argv[3],nullptr),age,1.f,2500.f*std::strtof(argv[3],nullptr)*std::min(1.f,age/8.f),8.f))throw std::runtime_error("encode failed");
   [command commit];[command waitUntilCompleted];if(command.status!=MTLCommandBufferStatusCompleted)throw std::runtime_error("GPU failed");if(repeat>=0)times.push_back((command.GPUEndTime-command.GPUStartTime)*1000.);
  }
  static std::vector<uint8_t> previous;static double meanSum=0,maxMean=0;static unsigned changes=0;
  std::vector<uint8_t> rgba(size_t(width)*height*4);[color getBytes:rgba.data() bytesPerRow:width*4 fromRegion:MTLRegionMake2D(0,0,width,height) mipmapLevel:0];
  if(frame){double total=0;unsigned changed=0;for(size_t i=0;i<rgba.size();i+=4){unsigned delta=0;for(unsigned channel=0;channel<3;channel++)delta+=std::abs(int(rgba[i+channel])-int(previous[i+channel]));total+=delta;if(delta>60)changed++;}double mean=total/(width*height*3);meanSum+=mean;maxMean=std::max(maxMean,mean);changes+=changed;}
  previous=rgba;
  if(frame==119){printf("mode=%u meanFrameDelta=%.6f maxFrameDelta=%.6f pixelsRgbDeltaOver60PerFrame=%.2f\n",camera,meanSum/119,maxMean,double(changes)/119);meanSum=0;maxMean=0;changes=0;}
  savePNG(color,[NSString stringWithFormat:@"%s/%s-m%u-f%03u.png",argv[1],argv[2],camera,frame]);
 }
 return 0;
}catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}}
