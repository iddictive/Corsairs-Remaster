#include "experiments/native-metal/engine/src/libs/ship/src/phonk_ordnance.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
int main(){using namespace storm::ship::phonk;
 assert(nuclearYield(0).tier==1&&nuclearYield(1).tier==10);
 assert(nuclearYield(-.1f).tier==1&&nuclearYield(1.1f).tier==1&&nuclearYield(std::numeric_limits<float>::quiet_NaN()).tier==1);
 unsigned histogram[10]={};
 for(unsigned i=0;i<100000;++i){float u=(float(i)+.5f)/100000.f;auto yield=nuclearYield(u*u);++histogram[yield.tier-1];}
 for(unsigned tier=1;tier<=10;++tier){auto yield=nuclearYield((float(tier)-.5f)/10.f);assert(yield.tier==tier);
  assert(yield.radius==220*tier&&yield.effectRadius==600*tier&&yield.visibleRadius==2500*tier);
  assert(nuclearPressureFront(yield,0)==0&&nuclearPressureFront(yield,8)==yield.visibleRadius);
  assert(nuclearPressureFront(yield,9)==yield.visibleRadius&&nuclearPressureFront(yield,1.92f)>=yield.effectRadius-.01f);
  assert(nuclearFireStrength(yield,yield.effectRadius*.5f)==1&&nuclearFireStrength(yield,yield.effectRadius)==0);
  assert(nuclearPressureDamage(yield,yield.radius)<=1&&nuclearPressureDamage(yield,yield.effectRadius)==0);
  for(float x=yield.radius;x<yield.effectRadius;x+=yield.radius*.13f)assert(nuclearPressureDamage(yield,x)>nuclearPressureDamage(yield,x+1));
  NuclearMissile launched;launched.yield=yield;NuclearBlast detonated;detonated.yield=launched.yield;auto missile=launched.yield;auto blast=detonated.yield;for(unsigned frame=0;frame<2000;++frame){auto front=nuclearPressureFront(blast,float(frame)/250.f);(void)front;assert(blast.tier==yield.tier&&blast.radius==yield.radius&&blast.visibleRadius==yield.visibleRadius);}
  std::printf("tier%u probability%.3f%% direct%.0fm physical%.0fm visual%.0fm\n",tier,histogram[tier-1]/1000.f,yield.radius,yield.effectRadius,yield.visibleRadius);
 }
 puts("yield endpoints/distribution/immutable-snapshot/front/arrival/damage/fire PASS");
}
