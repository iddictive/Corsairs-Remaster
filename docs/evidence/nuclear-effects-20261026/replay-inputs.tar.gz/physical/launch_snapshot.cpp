#include "experiments/native-metal/engine/src/libs/ship/src/phonk_ordnance.hpp"
#include <cassert>
#include <cstdio>
#include <unordered_map>
using entid_t=uint64_t;using namespace storm::ship::phonk;
struct ATTRIBUTES{bool live=true;unsigned index=1;ATTRIBUTES*child=nullptr;static bool IsLive(const ATTRIBUTES*p){return p&&p->live;}unsigned GetAttributeAsDword(const char*,unsigned){return index;}ATTRIBUTES*VerifyAttributeClass(const char*){return child?child:this;}};
struct Sea{ATTRIBUTES root,oldPhonk,newPhonk;ATTRIBUTES *AttributesPointer=&root;Sea(){root.child=&oldPhonk;}} sea;
struct Sample{float value=.91f;float GetFloat(){return value;}};
struct SHIP;
struct Core{std::unordered_map<entid_t,void*> entities;entid_t current=3;int mode=0,calls=0;Sample sample;SHIP*source=nullptr;void*GetEntityPointer(entid_t id){auto i=entities.find(id);return i==entities.end()?nullptr:i->second;}entid_t GetEntityId(const char*){return current;}Sample*Event(const char*); }core;
struct SHIP{OrdnanceState state;ATTRIBUTES character;entid_t sea_id=3;Sea *pSea=&sea;ATTRIBUTES*observed=nullptr;ATTRIBUTES*GetACharacter(){return &character;}bool PhonkActive(){return core.mode!=6;}void Run();};
Sample*Core::Event(const char*){++calls;if(mode==1)entities.erase(1);if(mode==2)entities.erase(3);if(mode==3)current=4;if(mode==4)source->character.live=false;if(mode==5)source->character.index=2;if(mode==7)sea.root.live=false;if(mode==8)sea.root.child=&sea.newPhonk;if(mode==10)source->state.target=CVECTOR(999.f,0.f,999.f);return mode==9?nullptr:&sample;}
NuclearMissile missileTo(const CVECTOR &launch, const CVECTOR &target, int32_t owner)
{
    const float distance = std::sqrt(~(target - launch));
    return {launch, target, 0.f, std::max(1.2f, distance / 950.f),
            std::clamp(distance * .16f, 65.f, 650.f), owner, true};
}
void SHIP::Run(){auto &state=this->state;const entid_t sourceId=1;const CVECTOR launch(0.f,0.f,0.f);auto *attributes=&sea.oldPhonk;
    const auto simulationSeaId = sea_id;
    auto *const simulationSea = pSea;
    const auto seaLive = [&] {
        return pSea == simulationSea && core.GetEntityPointer(simulationSeaId) == simulationSea &&
               core.GetEntityId("sea") == simulationSeaId;
    };
for(auto &missile:state.missiles){if(missile.active)continue;
            auto *launchCharacter = GetACharacter();
            if (!ATTRIBUTES::IsLive(launchCharacter)) return;
            const auto owner = launchCharacter->GetAttributeAsDword("index", uint32_t(-1));
            const auto target = state.target;
            // Reuse the tsunami's weighted severity once, only for an actual
            // launch. Aim/prediction/rendering never consume random samples.
            auto *sample = core.Event("SeaPhonk_NuclearPower");
            if (core.GetEntityPointer(sourceId) != this || !seaLive()) return;
            launchCharacter = GetACharacter();
            if (!ATTRIBUTES::IsLive(launchCharacter) ||
                launchCharacter->GetAttributeAsDword("index", uint32_t(-1)) != owner ||
                !ATTRIBUTES::IsLive(simulationSea->AttributesPointer) || !PhonkActive()) return;
            if (missile.active) continue;
            const auto yield = nuclearYield(sample ? sample->GetFloat() : -1.f);
            attributes = simulationSea->AttributesPointer->VerifyAttributeClass("Phonk");
            missile = missileTo(launch, target, int32_t(owner));
            missile.yield = yield;
            state.reload = nuclearReload;
            break;
 }
 observed=attributes;
}
int main(){for(int mode=0;mode<=10;++mode){core={};sea.root.live=true;sea.root.child=&sea.oldPhonk;SHIP ship;ship.state.target=CVECTOR(400.f,0.f,500.f);core.source=&ship;core.mode=mode;core.entities={{1,&ship},{3,&sea}};ship.Run();bool accepted=mode==0||mode==8||mode==9||mode==10;assert(core.calls==1&&ship.state.missiles[0].active==accepted);if(accepted){auto y=ship.state.missiles[0].yield;assert(y.tier==(mode==9?1:10));assert(ship.state.missiles[0].target.x==400&&ship.state.missiles[0].target.z==500);assert(ship.observed==(mode==8?&sea.newPhonk:&sea.oldPhonk));}}puts("actual-launch single-roll snapshot+fallback+owner/SEA/character/mode/attributes callback fences PASS");}
