#include "power.c"
int Rolls = 0;
float LastSeverity = 0.0;
void CapturePower()
{
    LastSeverity = SeaPhonk_NuclearPower();
    Rolls = Rolls + 1;
}
int Probe()
{
    SetEventHandler("ProbePower", "CapturePower", 0);
    int histogram[10];
    int i;
    for (i = 0; i < 10000; i++)
    {
        Event("ProbePower");
        if (LastSeverity < 0.0 || LastSeverity > 1.0) return 1;
        int tier = 1 + makeint(LastSeverity * 10.0);
        if (tier > 10) tier = 10;
        histogram[tier - 1] = histogram[tier - 1] + 1;
    }
    if (Rolls != 10000) return 2;
    if (histogram[0] < 2900 || histogram[0] > 3450) return 3;
    if (histogram[9] < 300 || histogram[9] > 750) return 4;
    if (histogram[0] <= histogram[1] || histogram[1] <= histogram[9]) return 5;
    return 0;
}
