#include "experiments/native-metal/engine/src/libs/ship/src/phonk_ordnance.hpp"
#include <cassert>
#include <cstdio>
#include <unordered_map>
using entid_t=uint64_t;using namespace storm::ship::phonk;
struct ATTRIBUTES{bool live=true;unsigned index=2;static bool IsLive(const ATTRIBUTES*p){return p&&p->live;}unsigned GetAttributeAsDword(const char*,unsigned){return index;}};
struct Sea{} sea;
struct Root{void *geo=this;};struct Model{Root root;Root*GetNode(int){return &root;}};
struct Result{int value=1;int GetInt(){return value;}};
struct SHIP;
struct Core{std::unordered_map<entid_t,void*> entities;entid_t current=3;int mode=0;Result result;void*GetEntityPointer(entid_t id){auto i=entities.find(id);return i==entities.end()?nullptr:i->second;}entid_t GetEntityId(const char*){return current;}Result*Event(const char*,const char*,ATTRIBUTES*,int,float); } core;
struct SHIP{bool bMounted=true;ATTRIBUTES character;Model model;entid_t id=1,sea_id=3;Sea *pSea=&sea;int captures=0,geometryVisits=0;entid_t GetId(){return id;}bool isDead(){return false;}ATTRIBUTES*GetACharacter(){return &character;}Model*GetModel(){++captures;return &model;}void Run(NuclearBlast&);};
Result*Core::Event(const char*,const char*,ATTRIBUTES *actor,int,float){if(mode==1)result.value=0;if(mode==2)entities.erase(2);if(mode==3)entities.erase(1);if(mode==4)entities.erase(3);if(mode==5)current=4;if(mode==6)actor->index=7;if(mode==7)actor->live=false;return &result;}
void SHIP::Run(NuclearBlast &blast){const int owner=1;
    const auto sourceId = GetId();
    const auto seed = blast.seed;
    const auto blastSeaId = sea_id;
    auto *const blastSea = pSea;
    const auto sourceLive = [&] {
        return core.GetEntityPointer(sourceId) == this && blast.seed == seed &&
               pSea == blastSea && core.GetEntityPointer(blastSeaId) == blastSea &&
               core.GetEntityId("sea") == blastSeaId;
    };
for(entid_t id:std::vector<entid_t>{2}){
        auto *ship = static_cast<SHIP *>(core.GetEntityPointer(id));
        auto *character = ship ? ship->GetACharacter() : nullptr;
        if (!ship || !ship->bMounted || ship->isDead() || !ATTRIBUTES::IsLive(character)) continue;
        const auto characterIndex = character->GetAttributeAsDword("index", uint32_t(-1));
        // Reuse the same policy before geometry/crew damage, including native
        // cuts which cannot rely on the later HP handler to protect immortals.
        auto *admitted = core.Event("SeaPhonk_NuclearWave", "alf", character, owner, 0.f);
        if (!sourceLive()) return;
        if (!admitted || admitted->GetInt() == 0) continue;
        ship = static_cast<SHIP *>(core.GetEntityPointer(id));
        character = ship ? ship->GetACharacter() : nullptr;
        if (!ship || !ship->bMounted || ship->isDead() || !ATTRIBUTES::IsLive(character) ||
            character->GetAttributeAsDword("index", uint32_t(-1)) != characterIndex) continue;
        auto *model = ship->GetModel();
        auto *root = model ? model->GetNode(0) : nullptr;
        if (!root || !root->geo) continue;

  ++ship->geometryVisits;
 }
}
int main(){for(int mode=0;mode<8;++mode){core={};SHIP source,victim;source.id=1;victim.id=2;core.mode=mode;core.entities={{1,&source},{2,&victim},{3,&sea}};NuclearBlast blast;blast.seed=1;source.Run(blast);assert(victim.captures==(mode==0?1:0)&&victim.geometryVisits==(mode==0?1:0));}puts("actual-direct-preflight rejects protection/removal/replacement before any model capture PASS");}
