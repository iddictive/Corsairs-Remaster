#include "experiments/native-metal/engine/src/libs/shared_headers/include/shared/sea_nuclear_wave.hpp"
#include <array>
#include <cassert>
#include <cstdio>
class SEA {
public:
 std::array<SeaNuclearWave,4> nuclearWaves{};bool nuclearWavesActive=false;
 void StartNuclearWave(float,float,unsigned,bool,float);
 void AdvanceNuclearWaves(float);
 float NuclearWaveHeightBound() const;
 SeaNuclearWaveSample NuclearWaveSample(float,float)const;
};
#include "sea_methods.cpp"
int main(){
 SEA sea;sea.StartNuclearWave(10,20,1,true,1.f);sea.AdvanceNuclearWaves(.2f);
 assert(sea.nuclearWavesActive&&sea.NuclearWaveHeightBound()>0&&sea.NuclearWaveSample(10,20).height>0);
 sea.StartNuclearWave(10,20,1,false,1.f);assert(!sea.nuclearWavesActive&&sea.NuclearWaveHeightBound()==0);
 sea.StartNuclearWave(10,20,1,true,1.f);sea.StartNuclearWave(30,40,2,true,1.f);sea.AdvanceNuclearWaves(1);
 sea.StartNuclearWave(50,60,1,true,1.f);assert(sea.nuclearWaves[1].age==0&&sea.nuclearWaves[1].x==50);
 assert(sea.nuclearWaves[2].age==1&&sea.nuclearWaves[2].active);
 sea.StartNuclearWave(50,60,1,false,1.f);assert(sea.nuclearWavesActive&&sea.nuclearWaves[2].active);
 sea.AdvanceNuclearWaves(8);assert(!sea.nuclearWavesActive&&sea.NuclearWaveHeightBound()==0);
 sea.StartNuclearWave(0,0,4,true,1.f);assert(!sea.nuclearWavesActive);
 SeaNuclearWave normal{0,0,0,0,true,1},strong{0,0,0,0,true,10};normal.Advance(2);strong.Advance(2);assert(normal.Front()==140&&strong.Front()==1400);auto n=EvaluateSeaNuclearWave(normal,140,0),s=EvaluateSeaNuclearWave(strong,1400,0);assert(n.height==s.height&&s.height<=4);normal.Advance(6);strong.Advance(6);assert(!normal.active&&!strong.active);
 puts("scale1/10-sameheight+8slife real-SEA sea/dry/slot-replace/other-slot-preserve/expiry/invalid-slot PASS");
}
