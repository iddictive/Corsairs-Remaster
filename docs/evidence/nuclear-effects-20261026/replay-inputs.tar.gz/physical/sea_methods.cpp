void SEA::StartNuclearWave(float x, float z, unsigned slot, bool active, float lengthScale)
{
    if (slot >= nuclearWaves.size() || !std::isfinite(x) || !std::isfinite(z)) return;
    nuclearWaves[slot] = {x, z, 0.f, 0.f, active,
        std::isfinite(lengthScale) ? std::clamp(lengthScale, 1.f, 10.f) : 1.f};
    nuclearWavesActive = std::any_of(nuclearWaves.begin(), nuclearWaves.end(),
        [](const auto &wave) { return wave.active; });
}

void SEA::AdvanceNuclearWaves(float seconds)
{
    if (!nuclearWavesActive || !(seconds > 0.f) || !std::isfinite(seconds)) return;
    nuclearWavesActive = false;
    for (auto &wave : nuclearWaves) {
        wave.Advance(seconds);
        nuclearWavesActive |= wave.active;
    }
}

float SEA::NuclearWaveHeightBound() const
{
    float height = 0.f;
    if (nuclearWavesActive) for (const auto &wave : nuclearWaves) height += wave.amplitude;
    return height;
}

SeaNuclearWaveSample SEA::NuclearWaveSample(float x, float z) const
{
    SeaNuclearWaveSample result;
    if (!nuclearWavesActive) return result;
    for (const auto &wave : nuclearWaves) {
        const auto sample = EvaluateSeaNuclearWave(wave, x, z);
        result.height += sample.height;
        result.slopeX += sample.slopeX;
        result.slopeZ += sample.slopeZ;
        result.foam = std::max(result.foam, sample.foam);
        result.load = std::max(result.load, sample.load);
    }
    return result;
}

