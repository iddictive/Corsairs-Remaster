float SeaTsunami_SampleSeverity()
{
	float strength = frnd();
	return strength * strength;
}
float SeaPhonk_NuclearPower()
{
    return SeaTsunami_SampleSeverity();
}
