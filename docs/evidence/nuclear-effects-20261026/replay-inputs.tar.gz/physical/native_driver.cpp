#define STORM_METAL_SHIP_FIRE
#include "experiments/native-metal/engine/src/libs/ship/src/phonk_ordnance.hpp"
#include "experiments/native-metal/engine/src/libs/shared_headers/include/shared/sea_nuclear_wave.hpp"
#include "experiments/native-metal/ship_fire_model.hpp"
#include <cassert>
#include <cstdio>
#include <unordered_map>
using entid_t=uint64_t;
constexpr int MSG_SHIP_ADD_MOVE_IMPULSE=1;
struct ATTRIBUTES {
    bool live=true; unsigned index=0;
    static bool IsLive(const ATTRIBUTES *p) { return p&&p->live; }
    unsigned GetAttributeAsDword(const char*,unsigned) const { return index; }
};
struct Matrix { CVECTOR operator*(CVECTOR p) const { return p; } };
struct Model { Matrix mtx; float trace=2; float Trace(CVECTOR,CVECTOR) { return trace; } };
struct Sea {float level=0; float WaveXZ(float,float) {return level;} };
Sea liveSea,replacementSea;
struct Island {float trace=2;float TraceWorldWeapon(CVECTOR,CVECTOR,entid_t&) {return trace;} };
struct Result {int accepted=1;int GetInt(){return accepted;}};
class SHIP {
public:
    entid_t id=0; bool bMounted=true,dead=false,retained=true,fireStateDirty=false;
    int saves=0; CVECTOR pos=0.f;ATTRIBUTES character;Model model;Sea *pSea=&liveSea;entid_t sea_id=3;Island *pIsland=nullptr;
    struct Link {std::size_t cell;};std::vector<Link> fireHulls;storm_ship_fire::Model shipFire;
    entid_t GetId(){return id;}bool isDead(){return dead;}ATTRIBUTES *GetACharacter(){return &character;}
    CVECTOR GetPos(){return pos;}Model *GetModel(){return &model;}
    bool IsHullPositionRetained(CVECTOR){return retained;}void SaveShipFire(){++saves;}
    void AdvancePhonkNuclearPressure(storm::ship::phonk::NuclearBlast&,const std::vector<entid_t>&);
    void IgnitePhonkNuclearFire(const CVECTOR&,float,int32_t,const std::vector<entid_t>&);
    void fill(){for(int i=0;i<8;++i){auto n=shipFire.add(float(i)*10.f,2,0,2.2f);fireHulls.push_back({n});}}
};
struct Core {
    std::unordered_map<entid_t,SHIP*> ships; Result result;int events=0,damageCalls=0,impulses=0;
    bool removeVictim=false,removeSource=false,removeSea=false,replaceSea=false;storm::ship::phonk::NuclearBlast *resetBlast=nullptr;
    Sea *scene=&liveSea;entid_t currentSea=3;
    entid_t GetEntityId(const char*) {return currentSea;}
    void *GetEntityPointer(entid_t id){if(id==3)return scene==&liveSea?scene:nullptr;auto i=ships.find(id);return i==ships.end()?nullptr:i->second;}
    Result *Event(const char*,const char*,ATTRIBUTES *target,int owner,float damage){
        ++events;if(damage>0&&result.accepted)++damageCalls;
        if(removeVictim)ships.erase(target->index);
        if(removeSource)ships.erase(1);
        if(removeSea)scene=nullptr;
        if(replaceSea){scene=&replacementSea;currentSea=4;}
        if(resetBlast)resetBlast->seed+=1;
        return &result;
    }
    void Send_Message(entid_t,const char*,int,int,float x,float,float z,float,float,float){
        ++impulses;assert(std::hypot(x,z)<=3.001f);
    }
} core;
#include "native_methods.cpp"
int active(const SHIP &s){int n=0;for(std::size_t i=0;i<s.shipFire.count;++i)n+=s.shipFire.cells[i].heat>0;return n;}
int main(){
    using namespace storm::ship::phonk;
    SHIP source;source.id=1;source.character.index=1;
    auto scenario=[&](float distance,bool direct,bool accepted,unsigned tier=1){
        core={};SHIP victim;victim.id=2;victim.character.index=2;victim.pos={distance,0,0};victim.fill();
        core.ships={{1,&source},{2,&victim}};core.result.accepted=accepted;
        NuclearBlast blast;blast.owner=1;blast.seed=1;blast.active=true;blast.yield=nuclearYield((float(tier)-.5f)/10.f);
        NuclearPressureContact contact;contact.ship=2;contact.directDamage=direct;contact.Query(distance,0);blast.contacts.push_back(contact);
        blast.age=distance/(blast.yield.visibleRadius/nuclearPressureLife)+.01f;
        source.AdvancePhonkNuclearPressure(blast,{2});
        int heated=active(victim);float heat=victim.shipFire.cells[0].heat;
        source.AdvancePhonkNuclearPressure(blast,{2});
        const bool reachable=distance<blast.yield.effectRadius;assert(core.events==(reachable?1:0) && core.impulses==(accepted&&reachable?1:0));
        assert(core.damageCalls==(!direct&&accepted&&reachable?1:0));
        assert(active(victim)==heated);
        std::printf("distance=%.0f direct=%d accepted=%d fires=%d heat=%.4f events=%d impulse=%d\n",distance,direct,accepted,heated,heat,core.events,core.impulses);
        return heated;
    };
    assert(scenario(300,false,true)==6);
    assert(scenario(450,false,true)==4);
    assert(scenario(599,false,true)==2);
    assert(scenario(600,false,true)==0);
assert(scenario(3000,false,true,10)==6);assert(scenario(4500,false,true,10)==4);assert(scenario(5999,false,true,10)==2);assert(scenario(6000,false,true,10)==0);
    assert(scenario(150,true,true)==6);
    assert(scenario(300,false,false)==0);
    for(int mode=0;mode<5;++mode){
        core={};SHIP victim;victim.id=2;victim.character.index=2;victim.pos=CVECTOR(300.f,0.f,0.f);victim.fill();core.ships={{1,&source},{2,&victim}};
        NuclearBlast blast;blast.owner=1;blast.seed=1;blast.active=true;blast.age=2;
        NuclearPressureContact contact;contact.ship=2;contact.Query(300,0);blast.contacts.push_back(contact);
        if(mode==0)core.removeVictim=true;if(mode==1)core.removeSource=true;if(mode==2)core.resetBlast=&blast;
        if(mode==3)core.removeSea=true;if(mode==4)core.replaceSea=true;
        source.AdvancePhonkNuclearPressure(blast,{2});assert(core.events==1&&core.impulses==0&&active(victim)==0);
    }
    for(int mode=0;mode<4;++mode){
        SHIP victim;victim.fill();Island island;Sea sea;
        if(mode==0){island.trace=.1f;victim.pIsland=&island;}
        if(mode==1)victim.model.trace=.1f;
        if(mode==2)victim.retained=false;
        if(mode==3){sea.level=100;victim.pSea=&sea;}
        victim.IgnitePhonkNuclearFire(CVECTOR(-300.f,2.f,0.f),1,1,{});assert(active(victim)==0);
    }
    NuclearPressureContact late;assert(!late.Query(100,nuclearPressureFront(NuclearYield{},2)));assert(!late.Query(600,nuclearPressureFront(NuclearYield{},2)));assert(!late.Query(100,nuclearPressureFront(NuclearYield{},2)));
    SeaNuclearWave wave{0,0,0,0,true};wave.Advance(2);auto before=wave;wave.Advance(0);assert(wave.age==before.age);
    SeaNuclearWave young{0,0,0,0,true};young.Advance(.2f);
    auto center=EvaluateSeaNuclearWave(young,0,0),epsilon=EvaluateSeaNuclearWave(young,.0001f,0);
    assert(center.height>0 && std::abs(center.height-epsilon.height)<.0001f && center.slopeX==0);
    assert(nuclearPressureFront(NuclearYield{},8)==2500.f&&nuclearPressureFront(nuclearYield(1),8)==25000.f);
    for(float x=80;x<200;x+=.37f){auto s=EvaluateSeaNuclearWave(wave,x,15);float g=(EvaluateSeaNuclearWave(wave,x+.05f,15).height-EvaluateSeaNuclearWave(wave,x-.05f,15).height)/.1f;assert(std::abs(s.slopeX-g)<.0002f);}
    wave.Advance(10);assert(!wave.active&&EvaluateSeaNuclearWave(wave,140,0).height==0);
    puts("real-method arrival+actualfiremodel+callbackremoval+shadow+submerged+late+watergradient PASS");
}
