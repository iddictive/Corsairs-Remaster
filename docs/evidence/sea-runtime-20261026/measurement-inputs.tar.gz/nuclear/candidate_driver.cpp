#define KNOTS2METERS(x) ((x)*1853.0f / 3600.0f)
#define STORM_METAL_SHIP_FIRE
#include "experiments/native-metal/engine/src/libs/ship/src/phonk_ordnance.hpp"
#include "experiments/native-metal/engine/src/libs/shared_headers/include/shared/sea_nuclear_wave.hpp"
#include "experiments/native-metal/ship_fire_model.hpp"
#include <cassert>
#include <cstdio>
#include <unordered_map>
using entid_t=uint64_t;
constexpr int MSG_SHIP_ADD_MOVE_IMPULSE=1;
struct ATTRIBUTES {
    bool live=true; unsigned index=0;
    static bool IsLive(const ATTRIBUTES *p) { return p&&p->live; }
    unsigned GetAttributeAsDword(const char*,unsigned) const { return index; }
};
struct Matrix { CVECTOR origin=0.f;CVECTOR operator*(CVECTOR p) const { return p+origin; } };
struct Model { Matrix mtx; float trace=2; float Trace(CVECTOR,CVECTOR) { return trace; } };
struct Sea {float level=0; float WaveXZ(float,float) {return level;} };
Sea liveSea,replacementSea;
struct Island {float trace=2;float TraceWorldWeapon(CVECTOR,CVECTOR,entid_t&) {return trace;} };
struct Result {int accepted=1;int GetInt(){return accepted;}};
int motionCalls=0;float lastKnots=0;
class SHIP {
public:
    entid_t id=0; bool bMounted=true,dead=false,retained=true,fireStateDirty=false;
    int saves=0; CVECTOR pos=0.f;ATTRIBUTES character;Model model;Sea *pSea=&liveSea;entid_t sea_id=3;Island *pIsland=nullptr;
    struct Link {std::size_t cell;};std::vector<Link> fireHulls;storm_ship_fire::Model shipFire;
    entid_t GetId(){return id;}bool isDead(){return dead;}ATTRIBUTES *GetACharacter(){return &character;}
    CVECTOR GetPos(){return pos;}Model *GetModel(){return &model;}
    bool IsHullPositionRetained(CVECTOR){return retained;}void SaveShipFire(){++saves;}
    void ApplyHullContactMotion(const CVECTOR &v,float,const CVECTOR&,float,uint32_t){++motionCalls;lastKnots=std::hypot(v.x,v.z)*3600.f/1853.f;}
    void AdvancePhonkNuclearPressure(storm::ship::phonk::NuclearBlast&,const std::vector<entid_t>&);
    void IgnitePhonkNuclearFire(const CVECTOR&,float,int32_t,const std::vector<entid_t>&);
    void fill(){for(int i=0;i<8;++i){auto n=shipFire.add(float(i)*10.f,2,0,2.2f);fireHulls.push_back({n});}}
};
struct Core {
    std::unordered_map<entid_t,SHIP*> ships; Result result;int events=0,damageCalls=0,impulses=0;
    bool removeVictim=false,removeSource=false,removeSea=false,replaceSea=false;bool killVictim=false;storm::ship::phonk::NuclearBlast *resetBlast=nullptr;
    Sea *scene=&liveSea;entid_t currentSea=3;
    entid_t GetEntityId(const char*) {return currentSea;}
    void *GetEntityPointer(entid_t id){if(id==3)return scene==&liveSea?scene:nullptr;auto i=ships.find(id);return i==ships.end()?nullptr:i->second;}
    Result *Event(const char*,const char*,ATTRIBUTES *target,int owner,float damage){
        ++events;if(damage>0&&result.accepted)++damageCalls;if(killVictim&&damage>0)ships[target->index]->dead=true;
        if(removeVictim)ships.erase(target->index);
        if(removeSource)ships.erase(1);
        if(removeSea)scene=nullptr;
        if(replaceSea){scene=&replacementSea;currentSea=4;}
        if(resetBlast)resetBlast->seed+=1;
        return &result;
    }
    void Send_Message(entid_t,const char*,int,int,float x,float,float z,float,float,float){
        ++impulses;lastKnots=std::hypot(x,z);
    }
} core;
#include "native_methods.cpp"
int active(const SHIP &s){int n=0;for(std::size_t i=0;i<s.shipFire.count;++i)n+=s.shipFire.cells[i].heat>0;return n;}


int main(){using namespace storm::ship::phonk;SHIP source;source.id=1;source.character.index=1;
 auto scenario=[&](float distance,bool dead,bool killed=false,bool accepted=true){core={};motionCalls=0;lastKnots=0;SHIP v;v.id=2;v.character.index=2;v.dead=dead;v.pos=CVECTOR(distance,0.f,0.f);v.model.mtx.origin=v.pos;v.fill();core.ships={{1,&source},{2,&v}};core.killVictim=killed;core.result.accepted=accepted;
 NuclearBlast b;b.owner=1;b.seed=1;b.active=true;b.yield=nuclearYield(1.f);NuclearPressureContact c;c.ship=2;c.Query(std::max(.001f,distance),0);b.contacts.push_back(c);b.age=distance/3125.f+.01f;source.AdvancePhonkNuclearPressure(b,{2});int n=active(v);float speed=lastKnots;int calls=motionCalls;source.AdvancePhonkNuclearPressure(b,{2});assert(active(v)==n&&motionCalls==calls);assert(core.damageCalls==(!dead&&accepted&&distance<6000.f?1:0));if(killed)assert(v.dead);assert(calls==(accepted&&distance<6000.f?1:0));printf("dead=%d killed=%d d=%.0f fires=%d knots=%.3f HP_calls=%d\n",dead,killed,distance,n,speed,core.damageCalls);return n;};
 assert(scenario(1000,true)==6);assert(scenario(1000,false,true)==6);assert(scenario(1500,true)==4);assert(scenario(1999,true)==2);assert(scenario(2000,true)==0);assert(scenario(3000,true)==0);assert(scenario(6000,true)==0);assert(scenario(1000,true,false,false)==0);assert(scenario(0,true)==6);
 for(int mode=0;mode<5;++mode){core={};motionCalls=0;SHIP v;v.id=2;v.character.index=2;v.dead=true;v.pos=CVECTOR(1000.f,0.f,0.f);v.fill();core.ships={{1,&source},{2,&v}};NuclearBlast b;b.owner=1;b.seed=1;b.active=true;b.yield=nuclearYield(1);b.age=.4f;NuclearPressureContact c;c.ship=2;c.Query(1000,0);b.contacts.push_back(c);if(mode==0)core.removeVictim=true;if(mode==1)core.removeSource=true;if(mode==2)core.resetBlast=&b;if(mode==3)core.removeSea=true;if(mode==4)core.replaceSea=true;source.AdvancePhonkNuclearPressure(b,{2});assert(!motionCalls&&!active(v));}
 for(int mode=0;mode<4;++mode){SHIP v;v.dead=true;v.fill();Island island;Sea sea;if(mode==0){island.trace=.1f;v.pIsland=&island;}if(mode==1)v.model.trace=.1f;if(mode==2)v.retained=false;if(mode==3){sea.level=100;v.pSea=&sea;}v.IgnitePhonkNuclearFire(CVECTOR(-300.f,2.f,0.f),1,1,{});assert(active(v)==0);}
 assert(nuclearFireStrength(nuclearYield(1),2000.f)==0);assert(nuclearPressureImpulse(nuclearYield(1),1000.f)==30.f);assert(nuclearPressureFront(nuclearYield(1),8)==25000.f);
 puts("wreck/post-kill thermal+momentum,2kmfire/6kmpressure,once-onlyHP,protection,callback lifetime,shield/submerged negatives PASS");}
