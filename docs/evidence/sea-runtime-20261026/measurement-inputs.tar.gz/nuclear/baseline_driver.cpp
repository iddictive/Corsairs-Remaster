#define STORM_METAL_SHIP_FIRE
#include "experiments/native-metal/engine/src/libs/ship/src/phonk_ordnance.hpp"
#include "experiments/native-metal/engine/src/libs/shared_headers/include/shared/sea_nuclear_wave.hpp"
#include "experiments/native-metal/ship_fire_model.hpp"
#include <cassert>
#include <cstdio>
#include <unordered_map>
using entid_t=uint64_t;
constexpr int MSG_SHIP_ADD_MOVE_IMPULSE=1;
struct ATTRIBUTES {
    bool live=true; unsigned index=0;
    static bool IsLive(const ATTRIBUTES *p) { return p&&p->live; }
    unsigned GetAttributeAsDword(const char*,unsigned) const { return index; }
};
struct Matrix { CVECTOR origin=0.f;CVECTOR operator*(CVECTOR p) const { return p+origin; } };
struct Model { Matrix mtx; float trace=2; float Trace(CVECTOR,CVECTOR) { return trace; } };
struct Sea {float level=0; float WaveXZ(float,float) {return level;} };
Sea liveSea,replacementSea;
struct Island {float trace=2;float TraceWorldWeapon(CVECTOR,CVECTOR,entid_t&) {return trace;} };
struct Result {int accepted=1;int GetInt(){return accepted;}};
int motionCalls=0;float lastKnots=0;
class SHIP {
public:
    entid_t id=0; bool bMounted=true,dead=false,retained=true,fireStateDirty=false;
    int saves=0; CVECTOR pos=0.f;ATTRIBUTES character;Model model;Sea *pSea=&liveSea;entid_t sea_id=3;Island *pIsland=nullptr;
    struct Link {std::size_t cell;};std::vector<Link> fireHulls;storm_ship_fire::Model shipFire;
    entid_t GetId(){return id;}bool isDead(){return dead;}ATTRIBUTES *GetACharacter(){return &character;}
    CVECTOR GetPos(){return pos;}Model *GetModel(){return &model;}
    bool IsHullPositionRetained(CVECTOR){return retained;}void SaveShipFire(){++saves;}
    void ApplyHullContactMotion(const CVECTOR &v,float,const CVECTOR&,float,uint32_t){++motionCalls;lastKnots=std::hypot(v.x,v.z)*3600.f/1853.f;}
    void AdvancePhonkNuclearPressure(storm::ship::phonk::NuclearBlast&,const std::vector<entid_t>&);
    void IgnitePhonkNuclearFire(const CVECTOR&,float,int32_t,const std::vector<entid_t>&);
    void fill(){for(int i=0;i<8;++i){auto n=shipFire.add(float(i)*10.f,2,0,2.2f);fireHulls.push_back({n});}}
};
struct Core {
    std::unordered_map<entid_t,SHIP*> ships; Result result;int events=0,damageCalls=0,impulses=0;
    bool removeVictim=false,removeSource=false,removeSea=false,replaceSea=false;storm::ship::phonk::NuclearBlast *resetBlast=nullptr;
    Sea *scene=&liveSea;entid_t currentSea=3;
    entid_t GetEntityId(const char*) {return currentSea;}
    void *GetEntityPointer(entid_t id){if(id==3)return scene==&liveSea?scene:nullptr;auto i=ships.find(id);return i==ships.end()?nullptr:i->second;}
    Result *Event(const char*,const char*,ATTRIBUTES *target,int owner,float damage){
        ++events;if(damage>0&&result.accepted)++damageCalls;
        if(removeVictim)ships.erase(target->index);
        if(removeSource)ships.erase(1);
        if(removeSea)scene=nullptr;
        if(replaceSea){scene=&replacementSea;currentSea=4;}
        if(resetBlast)resetBlast->seed+=1;
        return &result;
    }
    void Send_Message(entid_t,const char*,int,int,float x,float,float z,float,float,float){
        ++impulses;lastKnots=std::hypot(x,z);
    }
} core;
#include "native_methods.cpp"
int active(const SHIP &s){int n=0;for(std::size_t i=0;i<s.shipFire.count;++i)n+=s.shipFire.cells[i].heat>0;return n;}

int main(){using namespace storm::ship::phonk;
 for(bool dead:{false,true}){core={};motionCalls=0;lastKnots=0;SHIP source,victim;source.id=1;source.character.index=1;victim.id=2;victim.character.index=2;victim.dead=dead;victim.pos=CVECTOR(1000.f,0.f,0.f);victim.model.mtx.origin=victim.pos;victim.fill();core.ships={{1,&source},{2,&victim}};
 NuclearBlast b;b.owner=1;b.seed=1;b.active=true;b.yield=nuclearYield(1.f);NuclearPressureContact c;c.ship=2;c.Query(1000.f,0);b.contacts.push_back(c);b.age=.4f;source.AdvancePhonkNuclearPressure(b,{2});printf("dead=%d fires=%d motion=%d impulse_knots=%.3f events=%d\n",dead,active(victim),core.impulses+motionCalls,lastKnots,core.events);}
}
