#define METERS2KNOTS(x) ((x)*3600.0f / 1853.0f)
#define KNOTS2METERS(x) ((x)*1853.0f / 3600.0f)
#include "c_vector.h"
#include <cmath>
#include <algorithm>
#include <cassert>
#include <cstdio>
using BOOL=bool;
#define DELTA_TIME(x) ((x)*.001f)
struct GroundMotion{};struct TOUCH_PARAMS{CVECTOR vPos=0.f,vAng=0.f;};
struct SHIP{struct NativeState{CVECTOR vPos=0.f,vAng=0.f,vSpeed=0.f,vRotate=0.f;}State;
 CVECTOR vOldPos=0.f,vOldAng=0.f,vPos=0.f,vAng=0.f;bool dead=true,bKeelContour=false,phonk=false;int touches=0;
 struct Drift{bool initialized=false;float worldX=0,worldZ=0,lastForward=0;float magnitude(){return std::hypot(worldX,worldZ);}}phonkDrift;
 bool isDead(){return dead;}bool PhonkMotionAllowed(){return phonk;}float GroundPenetration(const NativeState&){return 0;}
 bool TouchMove(uint32_t,void*,TOUCH_PARAMS*){++touches;return true;}void ApplyWreckContact(CVECTOR){};
 BOOL Move(uint32_t,BOOL,GroundMotion * =nullptr);
 void ApplyHullContactMotion(const CVECTOR&,float,const CVECTOR&,float,uint32_t);
};
inline void RotateAroundY(float &x, float &z, float cos, float sin)
{
    const auto xx = x * cos + z * sin;
    const auto zz = z * cos - x * sin;
    x = xx;
    z = zz;
}
void SHIP::ApplyHullContactMotion(const CVECTOR &deltaWorldVelocity, float deltaYawVelocity,
                                  const CVECTOR &endWorldPosition, float endYaw, uint32_t milliseconds)
{
    if (!std::isfinite(deltaWorldVelocity.x) || !std::isfinite(deltaWorldVelocity.z) ||
        !std::isfinite(deltaYawVelocity) || !std::isfinite(endWorldPosition.x) ||
        !std::isfinite(endWorldPosition.z) || !std::isfinite(endYaw))
        return;
    if (isDead())
    {
        const float c = std::cos(State.vAng.y), s = std::sin(State.vAng.y);
        State.vSpeed.x += METERS2KNOTS(deltaWorldVelocity.x * c - deltaWorldVelocity.z * s);
        State.vSpeed.z += METERS2KNOTS(deltaWorldVelocity.x * s + deltaWorldVelocity.z * c);
        State.vRotate.y += deltaYawVelocity;
        if (!milliseconds) return;
        TOUCH_PARAMS predicted{};
        TouchMove(milliseconds, nullptr, &predicted);
        const float turn = endYaw - predicted.vAng.y;
        RotateAroundY(State.vSpeed.x, State.vSpeed.z, std::cos(-turn), std::sin(-turn));
        State.vAng.y += turn;
        vOldAng.y = State.vAng.y;
        vAng.y = State.vAng.y;
        TouchMove(milliseconds, nullptr, &predicted);
        ApplyWreckContact(CVECTOR(endWorldPosition.x - predicted.vPos.x, 0.f,
                                 endWorldPosition.z - predicted.vPos.z));
        return;
    }

    const bool phonk = PhonkMotionAllowed();
    const float c = std::cos(State.vAng.y), s = std::sin(State.vAng.y);
    if (phonk)
    {
        if (!phonkDrift.initialized)
        {
            phonkDrift.worldX = State.vSpeed.x * c + State.vSpeed.z * s;
            phonkDrift.worldZ = State.vSpeed.z * c - State.vSpeed.x * s;
            phonkDrift.initialized = true;
        }
        phonkDrift.worldX += METERS2KNOTS(deltaWorldVelocity.x);
        phonkDrift.worldZ += METERS2KNOTS(deltaWorldVelocity.z);
        phonkDrift.lastForward = phonkDrift.magnitude();
        State.vSpeed.x = 0.f;
        State.vSpeed.z = phonkDrift.lastForward;
    }
    else
    {
        State.vSpeed.x += METERS2KNOTS(deltaWorldVelocity.x * c - deltaWorldVelocity.z * s);
        State.vSpeed.z += METERS2KNOTS(deltaWorldVelocity.x * s + deltaWorldVelocity.z * c);
    }
    // Physical torque comes from r x J / I. Legacy shore impulses keep their
    // separate admission rule; this path never competes for Strength slots.
    State.vRotate.y += deltaYawVelocity;

    // Detached bodies execute after the ship's native step. Their reaction
    // changes momentum only; predicting another step here would rewind pose.
    if (!milliseconds) return;

    TOUCH_PARAMS predicted{};
    if (!TouchMove(milliseconds, nullptr, &predicted)) return;
    const float turn = endYaw - predicted.vAng.y;
    if (!phonk)
        RotateAroundY(State.vSpeed.x, State.vSpeed.z, std::cos(-turn), std::sin(-turn));
    State.vAng.y += turn;
    // Keep native controls, currents and damping. Offset the starting pose so
    // the next native step ends at the solved continuous-contact trajectory.
    if (!TouchMove(milliseconds, nullptr, &predicted)) return;
    State.vPos.x += endWorldPosition.x - predicted.vPos.x;
    State.vPos.z += endWorldPosition.z - predicted.vPos.z;
}
BOOL SHIP::Move(uint32_t DeltaTime, BOOL bCollision, GroundMotion *groundMotion)
{
    const auto dtime = DELTA_TIME(DeltaTime);
    if (isDead())
    {
        // Keep wreck momentum in the existing saved native state. Integrate
        // passive drag exactly so a long frame cannot reverse or add energy.
        const float seconds = std::max(0.f, dtime);
        const float drag = std::exp(-.3f * seconds), yawDrag = std::exp(-.6f * seconds);
        const float travel = -std::expm1(-.3f * seconds) / .3f;
        const float turn = State.vRotate.y * -std::expm1(-.6f * seconds) / .6f;
        const auto before = State;
        const float c = std::cos(State.vAng.y), s = std::sin(State.vAng.y);
        State.vPos.x += KNOTS2METERS(State.vSpeed.x * c + State.vSpeed.z * s) * travel;
        State.vPos.z += KNOTS2METERS(State.vSpeed.z * c - State.vSpeed.x * s) * travel;
        State.vAng.y += turn;
        State.vSpeed.x *= drag;
        State.vSpeed.z *= drag;
        RotateAroundY(State.vSpeed.x, State.vSpeed.z, std::cos(-turn), std::sin(-turn));
        State.vRotate.y *= yawDrag;
        // TOUCH excludes wreck/island pairs. Keep their new passive motion
        // from driving farther into terrain, without an outward kick.
        const bool moved = State.vPos.x != before.vPos.x || State.vPos.z != before.vPos.z ||
            State.vAng.y != before.vAng.y;
        if (moved && bKeelContour && GroundPenetration(State) > GroundPenetration(before) + .0001f)
        {
            State.vPos = before.vPos;
            State.vAng.y = before.vAng.y;
            State.vSpeed.x = State.vSpeed.z = State.vRotate.y = 0.f;
        }
        if (!bCollision)
        {
            vOldPos.x = State.vPos.x;
            vOldPos.z = State.vPos.z;
            vOldAng.y = State.vAng.y;
            vPos.x = State.vPos.x;
            vPos.z = State.vPos.z;
            vAng.y = State.vAng.y;
        }
        return true;
    }
return false;
}
int main(){SHIP a;a.State.vAng.y=.7f;a.State.vPos=CVECTOR(10.f,0.f,20.f);a.vOldPos=a.State.vPos;const CVECTOR kick(15.f,0.f,0.f);a.ApplyHullContactMotion(kick,0.f,a.State.vPos,0.f,0);assert(a.touches==0);SHIP b=a;assert(a.Move(1000,false));for(int i=0;i<100;++i)b.Move(10,false);const float travel=-std::expm1(-.3f)/.3f;assert(std::abs(a.State.vPos.x-10.f-15.f*travel)<.0001f);assert(std::abs(a.State.vPos.z-20.f)<.0001f);assert(std::abs(a.State.vPos.x-b.State.vPos.x)<.001f);assert(a.vOldPos.x==a.State.vPos.x);printf("actual passive wreck: x=%.4f expected=%.4f; one1s/100x10ms parity; saved death anchor retained\n",a.State.vPos.x,10.f+15.f*travel);SHIP live;live.dead=false;live.State.vAng.y=.7f;live.ApplyHullContactMotion(kick,0.f,CVECTOR(0.f),0,0);assert(live.State.vSpeed.x==METERS2KNOTS(kick.x*std::cos(.7f)));live.phonk=true;live.ApplyHullContactMotion(kick,0.f,CVECTOR(0.f),0,0);assert(live.phonkDrift.initialized&&live.touches==0);puts("native live/Phonk/dead momentum owner PASS");}
