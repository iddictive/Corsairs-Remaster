#include "crew_probe_prefix.hpp"
void ShipMan::ApplyTargetPoint(CVECTOR pt, bool randomWalk, const SHIP_BASE *)
{
    if (randomWalk)
    {
        // spread - 0.50

        ptTo.x = pt.x + (rand() / static_cast<float>(RAND_MAX) - rand() / static_cast<float>(RAND_MAX)) * 0.50f;
        ptTo.y = pt.y;
        ptTo.z = pt.z + (rand() / static_cast<float>(RAND_MAX) - rand() / static_cast<float>(RAND_MAX)) * 0.50f;
    }
    else
    {
        ptTo = pt;
    }

    dir = !(ptTo - pos);

    if (mode != MAN_CLIMB_UP)
    {
        angTo.y = Vector2Angle(dir);
    }
}
bool ShipMan::MoveToPosition(uint32_t &dltTime, SailorsPoints &sailorsPoints, ShipState &shipState)
{
    if (const auto model = static_cast<MODEL *>(core.GetEntityPointer(modelID)))
    {
        const auto dNow = SQR(pos.x - ptTo.x) + SQR(pos.y - ptTo.y) + SQR(pos.z - ptTo.z);

        const auto dFuture = SQR(pos.x + manSpeed * dir.x - ptTo.x) +
                             SQR(pos.y + manSpeed * dir.y - ptTo.y) + SQR(pos.z + manSpeed * dir.z - ptTo.z);

        if (shipState.dead && mode == MAN_CLIMB_UP &&
            dNow < sailorsPoints.points.point[newWayPoint].climbPosition * 10 + 1)
        {
            model->GetAnimation()->Player(0).Pause();
            sailorsPoints.points.point[newWayPoint].climbPosition++;
            mode = MAN_OFF;
            return false;
        }

        if (dFuture < dNow)
        {
            if (RotateToAngle(dltTime, sailorsPoints) || mode == MAN_RUN ||
                (mode == MAN_WALK && fabs(angTo.y - ang.y) < PI / 8))
            {
                pos += dir * (manSpeed * dltTime / 100.0f);
            }

            return false;
        }

        pos = ptTo;
        ang.y = angTo.y;

        return true;
    }

    return false;
}
void ShipWalk::ReconcileMastWaypoints()
{
    const int count = sailorsPoints.points.count;
    const auto available = [&](int i) {
        return i >= 0 && i < count && sailorsPoints.points.point[i].IsAvailable();
    };
    for (auto &man : shipMan)
    {
        if (man.inWater || man.mode == MAN_SWIM || man.mode == MAN_JUMP)
            continue;
        const bool onMast = man.mode == MAN_CLIMB_UP || man.mode == MAN_CLIMB_DOWN || man.mode == MAN_OFF;
        if (onMast && (!available(man.newWayPoint) || !available(man.lastWayPoint)))
        {
            for (const int i : {man.targetWayPoint, man.lastTargetPoint, man.newWayPoint})
                if (i >= 0 && i < count)
                    sailorsPoints.points.point[i].buisy = false;
            man.path = {};
            man.fireResponding = man.fireWorker = man.fireWorkRise = false;
            man.mode = MAN_JUMP;
            man.jumpSpeedX = JUMP_SPEED_X_MASTFALL;
            man.jumpSpeedY = 0.f;
            man.spos = CVECTOR(0.f, 0.f, 0.f);
            continue;
        }
        bool routeValid = available(man.newWayPoint) && available(man.targetWayPoint);
        for (int i = std::max(0, man.path.currentPointPosition); routeValid && i < man.path.length; ++i)
            routeValid = available(man.path.point[i]);
        if (routeValid)
            continue;
        for (const int i : {man.targetWayPoint, man.lastTargetPoint})
            if (i >= 0 && i < count)
                sailorsPoints.points.point[i].buisy = false;
        // Keep the current position and rejoin the surviving end of the authored
        // edge, rather than teleporting or continuing toward a removed station.
        int start = -1;
        float distance = INFINITY;
        for (const int i : {man.newWayPoint, man.lastWayPoint})
            if (available(i) && Dest(man.pos, CrewPoint(sailorsPoints.points.point[i])) < distance)
            {
                start = i;
                distance = Dest(man.pos, CrewPoint(sailorsPoints.points.point[i]));
            }
        man.path = {};
        man.fireResponding = man.fireWorker = man.fireWorkRise = false;
        man.moveTo = MOVE_TO_POINT;
        man.mode = start < 0 ? MAN_STAY : MAN_WALK;
        if (start >= 0)
        {
            man.newWayPoint = man.lastWayPoint = man.targetWayPoint = start;
            man.ApplyTargetPoint(CrewPoint(sailorsPoints.points.point[start]), false, ship);
        }
        else
            man.ptTo = man.pos;
        man.lastMode = MAN_OFF;
    }
}
void ShipWalk::SetMastBroken(int iMastIndex)
{
    for (auto i = 0; i < sailorsPoints.points.count; i++)
    {
        if (sailorsPoints.points.point[i].pointType == PT_TYPE_MAST_1 && iMastIndex == 1)
            sailorsPoints.points.point[i].disabled = true;

        if (sailorsPoints.points.point[i].pointType == PT_TYPE_MAST_2 && iMastIndex == 2)
            sailorsPoints.points.point[i].disabled = true;

        if (sailorsPoints.points.point[i].pointType == PT_TYPE_MAST_3 && iMastIndex == 3)
            sailorsPoints.points.point[i].disabled = true;

        if (sailorsPoints.points.point[i].pointType == PT_TYPE_MAST_4 && iMastIndex == 4)
            sailorsPoints.points.point[i].disabled = true;

        if (sailorsPoints.points.point[i].pointType == PT_TYPE_MAST_5 && iMastIndex == 5)
            sailorsPoints.points.point[i].disabled = true;
    }

    for (auto &man : shipMan)
    {
        if (sailorsPoints.points.point[man.newWayPoint].disabled ||
            sailorsPoints.points.point[man.lastWayPoint].disabled)
        {
            man.mode = MAN_JUMP;
            man.jumpSpeedX = JUMP_SPEED_X_MASTFALL;
        }
    }
    sailorsPoints.UpdateLinks();
    fireModelSeconds = -1.f;
    ReconcileMastWaypoints();
}
#include "crew_probe_main.hpp"
