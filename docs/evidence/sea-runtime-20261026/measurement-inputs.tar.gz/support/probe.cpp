#include "ship_laser_geometry.hpp"
#include "baseline.hpp"
#include "rdf.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <chrono>
using namespace storm_ship_laser;
template<class T>T read(std::ifstream&f){T v{};f.read((char*)&v,sizeof v);if(!f)throw std::runtime_error("short GM");return v;}
Mesh load(const char*path){std::ifstream f(path,std::ios::binary);const auto h=read<RDF_HEAD>(f);if(h.version!=RDF_VERSION)throw std::runtime_error("GM version");
 f.seekg(h.name_size+h.names*4+h.ntextures*4+h.nmaterials*sizeof(RDF_MATERIAL)+h.nlights*sizeof(RDF_LIGHT)+h.nlabels*sizeof(RDF_LABEL),std::ios::cur);
 std::vector<RDF_OBJECT>objects(h.nobjects);f.read((char*)objects.data(),objects.size()*sizeof(RDF_OBJECT));std::vector<RDF_TRIANGLE>triangles(h.ntriangles);f.read((char*)triangles.data(),triangles.size()*sizeof(RDF_TRIANGLE));std::vector<RDF_VERTEXBUFF>desc(h.nvrtbuffs);f.read((char*)desc.data(),desc.size()*sizeof(RDF_VERTEXBUFF));std::vector<std::vector<char>>vb(h.nvrtbuffs);for(size_t n=0;n<vb.size();++n){vb[n].resize(desc[n].size);f.read(vb[n].data(),vb[n].size());}if(!f)throw std::runtime_error("GM vertices");
 Mesh mesh;for(size_t n=0;n<objects.size();++n){const auto&o=objects[n];const auto&d=desc.at(o.vertex_buff);if(d.type>>2)continue;const unsigned stride=sizeof(RDF_VERTEX0)+(d.type&3)*8;for(int t=0;t<o.ntriangles;++t){Triangle tri;const auto&idx=triangles.at(o.striangle+t);for(unsigned c=0;c<3;++c){const auto at=size_t(o.svertex+idx.vindex[c])*stride;if(at+sizeof(RDF_VERTEX0)>vb[o.vertex_buff].size())throw std::runtime_error("GM index");std::memcpy(&tri[c].position,vb[o.vertex_buff].data()+at,12);std::memcpy(&tri[c].normal,vb[o.vertex_buff].data()+at+12,12);}mesh[int(n)].push_back(tri);}}return mesh;}
std::vector<Vec3>points(const char*path){std::ifstream f(path);std::string line;std::vector<Vec3>base,result;std::vector<std::array<unsigned,2>>links;while(std::getline(f,line)){unsigned n,a,b;Vec3 p;if(sscanf(line.c_str(),"point %u = %f,%f,%f",&n,&p.x,&p.y,&p.z)==4){if(base.size()<=n)base.resize(n+1);base[n]=p;}if(sscanf(line.c_str(),"link %u = %u,%u",&n,&a,&b)==3)links.push_back({a,b});}for(const auto&l:links)for(unsigned i=0;i<64;++i){const float t=(i+.317f)/64.f;result.push_back(base.at(l[0])*(1-t)+base.at(l[1])*t);}return result;}
uint64_t run(const Surface&s,const FaceIndex&i,const std::vector<FaceIndex>&released,const std::vector<Vec3>&p,bool baseline,std::vector<unsigned char>*out=nullptr){std::vector<uint32_t>a,b;uint64_t hash=1469598103934665603ull;for(auto v:p){bool r=baseline?supportRetainedBaseline(s,i,released,v,&a,&b):supportRetained(s,i,released,v,&a,&b);hash=(hash^r)*1099511628211ull;if(out)out->push_back(r);}return hash;}
int main(int argc,char**argv){if(argc<3)return 2;auto mesh=load(argv[1]);auto p=points(argv[2]);auto original=std::make_shared<SurfaceBase>();original->outer=mesh;original->index=indexFaces(mesh);Surface s;s.original=original;s.checkpointed=true;Mesh removed;size_t triangles=0,kept=0;for(const auto&obj:mesh)for(const auto&t:obj.second){auto center=(t[0].position+t[1].position+t[2].position)*(1.f/3);if(center.x>0&&center.z>0)removed[obj.first].push_back(t);else{s.outer[obj.first].push_back(t);++kept;}++triangles;}
 if(argc>3&&std::string(argv[3])=="all-deleted"){s.outer.clear();removed=mesh;kept=0;}
 const auto retained=indexFaces(s.outer);if(argc>3&&std::string(argv[3])=="nearest-deleted"){std::erase_if(p,[&](Vec3 v){return supportRetainedBaseline(s,retained,{},v);});}
 std::cout<<"triangles="<<triangles<<" kept="<<kept<<" moving_points="<<p.size()<<"\n";
 for(unsigned state=0;state<3;++state){std::vector<FaceIndex>released;if(state==1){s.checkpointed=false;s.released={std::make_shared<Mesh>(removed)};released.push_back(indexFaces(removed));}if(state==2){s.checkpointed=false;s.released.clear();}
  std::vector<unsigned char>a,b;const auto ha=run(s,retained,released,p,true,&a),hb=run(s,retained,released,p,false,&b);if(a!=b){std::cerr<<"PARITY_FAIL state="<<state<<"\n";return 1;}std::cout<<"state="<<state<<" hash="<<ha<<" candidate="<<hb<<" retained="<<std::count(a.begin(),a.end(),1)<<"\n";
  for(unsigned round=0;round<7;++round)for(unsigned branch=0;branch<2;++branch){const bool baseline=(round+branch)%2==0;const auto begin=std::chrono::steady_clock::now();auto h=run(s,retained,released,p,baseline);const auto ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();std::cout<<"round="<<round<<" mode="<<(baseline?"baseline":"candidate")<<" state="<<state<<" ms="<<std::setprecision(9)<<ms<<" hash="<<h<<"\n";}
 }
 return 0;
}
