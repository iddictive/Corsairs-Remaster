#include "c_vector.h"
#include <algorithm>
#include <vector>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <stdexcept>
#define SQR(v) ((v)*(v))
constexpr float PI=3.14159265358979323846f,JUMP_SPEED_X_MASTFALL=1.f;
enum {MAN_STAY,MAN_WALK,MAN_RUN,MAN_CLIMB_UP,MAN_CLIMB_DOWN,MAN_OFF,MAN_JUMP,MAN_SWIM,MOVE_TO_POINT,PT_TYPE_MAST_1=21,PT_TYPE_MAST_2,PT_TYPE_MAST_3,PT_TYPE_MAST_4,PT_TYPE_MAST_5};
float Vector2Angle(CVECTOR p){return std::atan2(p.x,p.z);}
float Dest(CVECTOR a,CVECTOR b){return std::sqrt(~(a-b));}
struct SHIP_BASE{mutable unsigned calls=0;bool IsHullPositionRetained(const CVECTOR&)const{++calls;return false;}};
struct Player{unsigned paused=0;void Pause(){++paused;}};
struct Animation{struct Player player;struct Player&Player(unsigned){return player;}};
struct MODEL{Animation animation;Animation*GetAnimation(){return &animation;}};
struct Core{MODEL model;void*GetEntityPointer(unsigned){return &model;}}core;
struct Point{float x=0,y=0,z=0;int pointType=0;bool disabled=false,hullRetained=true,buisy=false;int climbPosition=0;bool IsAvailable()const{return !disabled&&hullRetained;}};
struct SailorsPoints{struct{int count=0;std::vector<Point>point;}points;unsigned rebuilt=0;void UpdateLinks(){++rebuilt;}};
CVECTOR CrewPoint(const Point&p){return {p.x,p.y,p.z};}
struct ShipState{bool dead=false;SHIP_BASE*hull=nullptr;};
struct Path{int currentPointPosition=0,length=0;float min=0;int point[10]{};};
struct ShipMan{CVECTOR pos{0.f},ptTo{0.f},dir{0.f},ang{0.f},angTo{0.f},spos{0.f};float manSpeed=1,jumpSpeedX=0,jumpSpeedY=0;int mode=MAN_WALK,lastMode=MAN_OFF,moveTo=MOVE_TO_POINT,newWayPoint=0,lastWayPoint=0,targetWayPoint=0,lastTargetPoint=0;bool inWater=false,fireResponding=false,fireWorker=false,fireWorkRise=false;Path path;unsigned modelID=0;bool RotateToAngle(uint32_t&,SailorsPoints&){return true;}void ApplyTargetPoint(CVECTOR,bool,const SHIP_BASE* =nullptr);bool MoveToPosition(uint32_t&,SailorsPoints&,ShipState&);};
struct ShipWalk{SHIP_BASE*ship=nullptr;SailorsPoints sailorsPoints;std::vector<ShipMan>shipMan;float fireModelSeconds=1;void ReconcileMastWaypoints();void SetMastBroken(int);};
