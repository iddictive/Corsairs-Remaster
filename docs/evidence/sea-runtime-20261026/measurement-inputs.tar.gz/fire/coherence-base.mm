#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <ImageIO/ImageIO.h>
#import <CoreGraphics/CoreGraphics.h>
#include <chrono>
#include <cstdio>
#include <vector>
#include <algorithm>
#include "experiments/native-metal/ship_fire_render.hpp"
#include "engine/src/libs/core/src/timer.h"
#include "ship_fire_projection.hpp"
using Clock=std::chrono::steady_clock;
static constexpr unsigned W=384,H=256;
static void savePNG(const std::vector<unsigned char>&data,const char*path){
 auto provider=CGDataProviderCreateWithData(nullptr,data.data(),data.size(),nullptr);
 auto space=CGColorSpaceCreateDeviceRGB();
 auto image=CGImageCreate(W,H,8,32,W*4,space,kCGBitmapByteOrder32Little|kCGImageAlphaPremultipliedFirst,provider,nullptr,false,kCGRenderingIntentDefault);
 auto url=[NSURL fileURLWithPath:[NSString stringWithUTF8String:path]];
 auto destination=CGImageDestinationCreateWithURL((__bridge CFURLRef)url,CFSTR("public.png"),1,nullptr);
 CGImageDestinationAddImage(destination,image,nullptr);CGImageDestinationFinalize(destination);
 CFRelease(destination);CGImageRelease(image);CGColorSpaceRelease(space);CGDataProviderRelease(provider);
}
int main(int argc,const char**argv){@autoreleasepool{
 if(argc!=2&&argc!=3)return 2;auto device=MTLCreateSystemDefaultDevice();auto queue=[device newCommandQueue];
 auto descriptor=[MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm width:W height:H mipmapped:NO];
 descriptor.storageMode=MTLStorageModeShared;descriptor.usage=MTLTextureUsageRenderTarget|MTLTextureUsageShaderRead;
 auto target=[device newTextureWithDescriptor:descriptor];descriptor.pixelFormat=MTLPixelFormatDepth32Float;descriptor.storageMode=MTLStorageModePrivate;
 auto depth=[device newTextureWithDescriptor:descriptor];FrameArena arena;storm_metal::ShipFireRenderer renderer;
 auto root=matrix_identity_float4x4,view=matrix_identity_float4x4;view.columns[3].y=-3.5f;
 const float near=.3f,far=100.f,s=1.f/tanf(.72f*.5f);
 simd_float4x4 projection={{{s/(float(W)/H),0,0,0},{0,s,0,0},{0,0,far/(far-near),1},{0,0,-near*far/(far-near),0}}};
 StormMetalShipFirePoint point={{0.f,0.f,20.f},1.1f,.85f,.4f,.9f,2.7f};const float wind[]={1.2f,0,.2f};
 FILE*csv=fopen((std::string(argv[1])+"/coherence.csv").c_str(),"w");fprintf(csv,"case,samples,frame,phase,lod,scale,hash,mae,fire_area,centroid_x,centroid_y,cpu_encode_ms,gpu_ms\n");
 for(int scenario=0;scenario<3;scenario++)for(int candidate=0;candidate<2;candidate++){
  const char*name=scenario==0?"fixed-camera":scenario==1?"moving-camera":"thermal";const float scale=1.f;
  TIMER timer;auto origin=timer.Current;double remainder=0;float phase=argc==3?std::strtof(argv[2],nullptr):4.f;std::vector<unsigned char>previous,bytes(W*H*4);std::vector<double>cpu,gpu;unsigned changedFrames=0,phaseChanges=0;
  for(unsigned frame=0;frame<120;frame++){@autoreleasepool{
   timer.Run(origin+std::chrono::nanoseconds((1000000000LL*(frame+1))/60));timer.visualDeltaTime*=scale;
   double scaled=timer.Delta_Time*double(scale)+remainder;timer.Delta_Time=uint32_t(scaled);remainder=scaled-timer.Delta_Time;
   float old=phase;if(scenario!=1)phase+=std::min(1.f,timer.GetVisualDeltaTime()*.001f);phaseChanges+=phase!=old;
   if(scenario==1)view.columns[3].z=44.5f+.8f*float(frame)/119.f-20.f;
   else view.columns[3].z=0.f;
   if(scenario==2){storm_ship_fire::Model model;model.add(0,0,20,1.1f,false);model.cells[0].heat=.85f;storm_ship_fire::Context context;context.crewCount=30;context.priority=true;for(unsigned n=0;n<frame/15;n++)model.step(context);auto points=storm_ship_fire::volumePoints(model,2.7f,[](const auto&){return true;});point=points[0];}
   else point={{0.f,0.f,20.f},1.1f,.85f,.4f,.9f,2.7f};
   auto command=[queue commandBuffer];auto pass=[MTLRenderPassDescriptor renderPassDescriptor];
   pass.colorAttachments[0].texture=target;pass.colorAttachments[0].loadAction=MTLLoadActionClear;pass.colorAttachments[0].storeAction=MTLStoreActionStore;pass.colorAttachments[0].clearColor=MTLClearColorMake(.03,.07,.10,1);
   pass.depthAttachment.texture=depth;pass.depthAttachment.loadAction=MTLLoadActionClear;pass.depthAttachment.storeAction=MTLStoreActionStore;pass.depthAttachment.clearDepth=1;
   auto encoder=[command renderCommandEncoderWithDescriptor:pass];[encoder endEncoding];auto start=Clock::now();
   if(!renderer.append(reinterpret_cast<const float*>(&root),&point,1,wind,phase,{0,0,0},view,projection,{0,0,W,H},{0,0,0,1},{0,0,0,0},.7f))return 3;
   float lod=renderer.volumes[0].lod.x;if(candidate)for(auto&v:renderer.volumes)v.lod.x=80;
   if(!renderer.encode(device,command,target,depth,arena))return 3;
   double encode=std::chrono::duration<double,std::milli>(Clock::now()-start).count();[command commit];[command waitUntilCompleted];if(command.error)return 4;
   [target getBytes:bytes.data() bytesPerRow:W*4 fromRegion:MTLRegionMake2D(0,0,W,H) mipmapLevel:0];
   uint64_t hash=1469598103934665603ull;unsigned changed=0;for(size_t i=0;i<bytes.size();i++){hash=(hash^bytes[i])*1099511628211ull;if(!previous.empty())changed+=bytes[i]!=previous[i];}
   changedFrames+=changed!=0;double duration=(command.GPUEndTime-command.GPUStartTime)*1000.;
   double mae=0,cx=0,cy=0;unsigned area=0;for(size_t i=0;i<bytes.size();i+=4){if(!previous.empty())for(unsigned c=0;c<3;c++)mae+=std::abs(int(bytes[i+c])-int(previous[i+c]));if(bytes[i+2]>50&&bytes[i+2]>bytes[i+1]*1.5f){area++;cx+=(i/4)%W;cy+=(i/4)/W;}}mae/=W*H*3.;
   fprintf(csv,"%s,%s,%u,%.9g,%.6f,%.6f,%016llx,%.9f,%u,%.9f,%.9f,%.6f,%.6f\n",name,candidate?"80":"production",frame,phase,lod,renderer.budget.renderScale,(unsigned long long)hash,mae,area,cx/std::max(1u,area),cy/std::max(1u,area),encode,duration);
   if(frame<8||(frame>=14&&frame<=16)||(frame>=55&&frame<=65)||frame==119){char path[1024];snprintf(path,sizeof(path),"%s/%s-%s-%03u.png",argv[1],name,candidate?"80":"production",frame);savePNG(bytes,path);}
   if(frame>4){cpu.push_back(encode);gpu.push_back(duration);}previous=bytes;if(!arena.rewindAfterCompletion(0,command))return 5;
  }}
  std::sort(cpu.begin(),cpu.end());std::sort(gpu.begin(),gpu.end());
  printf("%s %s: phase_changes=%u/120 pixel_changes=%u/119 final_phase=%.9g CPU_encode_median=%.6fms GPU_median=%.6fms GPU_p95=%.6fms\n",name,candidate?"visual":"integer",phaseChanges,changedFrames,phase,cpu[cpu.size()/2],gpu[gpu.size()/2],gpu[gpu.size()*95/100]);
 }fclose(csv);return 0;
}}
