from pathlib import Path
import subprocess,os,sys
p=Path(sys.argv[1]);root=Path('REPO_ROOT');scratch=Path(os.environ['CODEX_SCRATCH_DIR'])
cmd=['/usr/bin/clang++','-std=c++20','-O2','-fobjc-arc','-mmacosx-version-min=15.0','-DPROBE_ROUNDS=0','-DRESOURCE_HEADER="'+str(root/'experiments/native-metal/resources.hpp')+'"','-I'+str(root/'experiments/native-metal'),str(p/'probe-final.mm'),'-framework','Foundation','-framework','Metal','-o',str(scratch/'final')]
(p/'compile-final.txt').write_text(' '.join(cmd)+'\n');subprocess.run(cmd,check=True)
r=subprocess.run([str(scratch/'final'),str(p/'inputs.txt')],text=True,capture_output=True);(p/'final.txt').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr,flush=True);r.check_returncode()
