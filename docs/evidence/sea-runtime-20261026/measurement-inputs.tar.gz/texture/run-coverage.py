from pathlib import Path
import subprocess,os,sys
p=Path(sys.argv[1]);root=Path('REPO_ROOT');scratch=Path(os.environ['CODEX_SCRATCH_DIR'])
for mode,header in [('coverage-before','resources-before.hpp'),('coverage-after','resources-coverage.hpp')]:
 cmd=['/usr/bin/clang++','-std=c++20','-O2','-fobjc-arc','-mmacosx-version-min=15.0','-DRESOURCE_HEADER="'+str(p/header)+'"','-I'+str(root/'experiments/native-metal'),str(p/'probe-coverage.mm'),'-framework','Foundation','-framework','Metal','-o',str(scratch/mode)]
 (p/('compile-'+mode+'.txt')).write_text(' '.join(cmd)+'\n');subprocess.run(cmd,check=True)
for mode in ['coverage-before','coverage-after']:
 r=subprocess.run([str(scratch/mode),str(p/'inputs.txt')],text=True,capture_output=True);(p/(mode+'.txt')).write_text(r.stdout+r.stderr);print(mode+'\n'+r.stdout+r.stderr,flush=True);r.check_returncode()
