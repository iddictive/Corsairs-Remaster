from pathlib import Path
b=Path('MEASUREMENT_DIR')
s=Path('experiments/native-metal/phonk_ordnance_shaders.hpp').read_text()
a=s.index('    float4 ground=0;');z=s.index('    // A vertical world-space smoke card',a)
s=s[:a]+'''    float4 ground=0;
    if(sceneDepth<1.f && u.params.x<u.params.z) {
        float3 at=(phonkNuclearUnproject(pixel.xy,sceneDepth,u)-u.sourceRadius.xyz)/radius;
        float width=u.eye.w,front=u.params.y,radial=length(at.xz);
        float footprint=fwidth(radial),feather=max(width,footprint*.45f);
        float3 dx=dfdx(at),dy=dfdy(at),normal=cross(dx,dy);
        normal=length(normal)>1.e-8f?normalize(normal):float3(0,1,0);
        if(dot(normal,ray)>0.f)normal=-normal;
        float incidence=max(.035f,-dot(normal,ray));
        float height=width*3.f,length=min(height/incidence,width*8.f);
        if(abs(radial-front)<width*10.f+footprint) {
            float turn=u.params.x*1.3f,cs=cos(turn),sn=sin(turn);
            float step=length/6.f,transmission=1.f;float3 color=0;
            for(uint i=0;i<6;i++) {
                float distance=(float(i)+.5f)*step;
                float3 p=at-ray*distance;float lift=distance*incidence;
                float r=length(p.xz)-front;
                float2 section=float2((r+width*.5f)/(width*1.6f+feather*.5f),(lift-width*.9f)/(width*1.25f));
                float body=1.f-smoothstep(.65f,1.25f,length(section));
                if(body>0.f) {
                    float2 rolled=float2(cs*section.x-sn*section.y,sn*section.x+cs*section.y);
                    float detail=.65f;
                    if(footprint<width*3.f)detail=phonkNuclearNoise(p/(width*2.f)+float3(rolled*.8f,0)+variation.xyz*23.f,noise);
                    float density=body*smoothstep(.18f,.82f,detail)*1.4f;
                    float alpha=1.f-exp(-density*step/width*.38f);
                    float lighting=.63f+.30f*lift/height+.20f*detail;
                    float3 spray=float3(.74f,.79f,.81f)*lighting;
                    color+=transmission*spray*alpha;transmission*=1.f-alpha;
                }
            }
            float alpha=1.f-transmission;
            float fade=smoothstep(0.f,.12f,u.params.x)*(1.f-smoothstep(max(0.f,u.params.z-.5f),u.params.z,u.params.x));
            float limit=alpha>.001f?min(alpha,.65f)/alpha:0.f;
            ground=float4(color,alpha)*(fade*limit);
        }
    }
'''+s[z:]
(b/'volume_shader.hpp').write_text(s)
r=Path('experiments/native-metal/phonk_ordnance_render.hpp').read_text().replace('#include "phonk_ordnance_shaders.hpp"','#include "volume_shader.hpp"')
r=r.replace('pressureFront/radius+2.f*band','pressureFront/radius+10.f*band')
r=r.replace('if (crossesNear) {','if (crossesNear || age<pressureLife) {')
(b/'volume_renderer.hpp').write_text(r)
p=(b/'terrain_probe.mm').read_text().replace('#include "experiments/native-metal/phonk_ordnance_render.hpp"','#include "volume_renderer.hpp"')
(b/'volume_probe.mm').write_text(p)
