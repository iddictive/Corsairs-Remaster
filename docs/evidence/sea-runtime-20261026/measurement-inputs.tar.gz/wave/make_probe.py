from pathlib import Path
base=Path('MEASUREMENT_DIR')
s=(base/'render/scale_production.mm').read_text()
s=s.replace('float3(.40f,.47f,.50f),zenith=float3(.075f,.14f,.22f)','float3(.68f,.77f,.85f),zenith=float3(.38f,.58f,.80f)')
a=s.index(' if(ray.z<-.001f) {'); b=s.index(' float3 sky=',a);s=s[:a]+s[b:]
s=s.replace('float3(.035f,.10f,.13f),horizon*.65f','float3(.34f,.52f,.61f),horizon*.85f')
s=s.replace(')MSL";','''struct TerrainV {packed_float3 p,n;};
struct TerrainO {float4 p [[position]];float3 normal,world;};
vertex TerrainO terrain_vs(uint id [[vertex_id]],const device TerrainV*vertices [[buffer(0)]],constant DemoCamera&c [[buffer(1)]]) {
 TerrainV v=vertices[id];return {c.viewProjection*float4(v.p,1),float3(v.n),float3(v.p)};
}
fragment float4 terrain_fs(TerrainO v [[stage_in]]) {
 float3 n=normalize(v.normal);float light=.40f+.60f*max(0.f,dot(n,normalize(float3(-.48f,.81f,-.32f))));
 float3 stone=mix(float3(.42f,.36f,.24f),float3(.29f,.37f,.22f),smoothstep(8.f,120.f,v.world.y)*n.y);
 return float4(stone*light,1);
}
)MSL";''')
s=s.replace('for(unsigned camera=0;camera<2;++camera)for(float age:{.5f,2.f,4.f,6.f,7.6f,8.1f}){','for(unsigned camera=0;camera<2;++camera)for(float age:{1.5f,2.5f,3.5f,4.5f,6.f,8.1f}){')
s=s.replace('auto eye=simd_make_float3(camera?0.f:90.f,camera?35.f:120.f,camera?650.f:6000.f);auto view=lookAt(eye,simd_make_float3(0.f,200.f,0.f))','auto eye=simd_make_float3(1700.f,camera?950.f:450.f,camera?6000.f:3000.f);auto view=lookAt(eye,simd_make_float3(600.f,80.f,0.f))')
s=s.replace('simd_make_float3(0.f,200.f,0.f)-eye','simd_make_float3(600.f,80.f,0.f)-eye')
old=' storm_metal::PhonkNuclearRenderer nuclear;'
assert s.count(old)==1
s=s.replace(old,''' pd.vertexFunction=[library newFunctionWithName:@"terrain_vs"];pd.fragmentFunction=[library newFunctionWithName:@"terrain_fs"];
 auto terrainPipeline=[device newRenderPipelineStateWithDescriptor:pd error:&error];if(!terrainPipeline)throw std::runtime_error(error.localizedDescription.UTF8String);
 dd.depthCompareFunction=MTLCompareFunctionLess;auto terrainDepth=[device newDepthStencilStateWithDescriptor:dd];
 struct Vertex {float p[3],n[3];};std::vector<Vertex> vertices;
 auto terrain=[](float x,float z){float a=(x-900.f)/580.f,b=z/590.f,c=(x-550.f)/350.f,d=(z+270.f)/350.f;return 340.f*std::exp(-a*a-b*b)+130.f*std::exp(-c*c-d*d)-9.f;};
 for(unsigned z=0;z<80;++z)for(unsigned x=0;x<80;++x)for(unsigned i:{0u,1u,2u,2u,1u,3u}) {
  float px=-500.f+(x+(i&1))*2600.f/80.f,pz=-1100.f+(z+(i>>1))*2200.f/80.f;
  auto n=simd_normalize(simd_make_float3(terrain(px-1,pz)-terrain(px+1,pz),2.f,terrain(px,pz-1)-terrain(px,pz+1)));
  vertices.push_back({{px,terrain(px,pz),pz},{n.x,n.y,n.z}});
 }
 auto terrainBuffer=[device newBufferWithBytes:vertices.data() length:vertices.size()*sizeof(Vertex) options:MTLResourceStorageModeShared];
 storm_metal::PhonkNuclearRenderer nuclear;''')
s=s.replace('[encoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];[encoder endEncoding];','''[encoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];
   [encoder setRenderPipelineState:terrainPipeline];[encoder setDepthStencilState:terrainDepth];[encoder setCullMode:MTLCullModeNone];
   [encoder setVertexBuffer:terrainBuffer offset:0 atIndex:0];[encoder setVertexBytes:&c length:sizeof(c) atIndex:1];
   [encoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:vertices.size()];[encoder endEncoding];''')
(base/'terrain_probe.mm').write_text(s)
