#import <Cocoa/Cocoa.h>
#import <Metal/Metal.h>
#include <simd/simd.h>
#include <algorithm>
#include <cstdio>
#include <vector>
#include <stdexcept>
#include "experiments/native-metal/phonk_ordnance_render.hpp"
constexpr unsigned width=960,height=540;
struct DemoCamera {simd_float4x4 viewProjection,inverseViewProjection;simd_float4 eye,viewport,sun,time;};
const char*sceneMSL=R"MSL(
struct DemoCamera {float4x4 viewProjection,inverseViewProjection;float4 eye,viewport,sun,time;};
struct SceneO {float4 p [[position]];};
struct ScenePixel {float4 color [[color(0)]];float depth [[depth(any)]];};
vertex SceneO demo_scene_vs(uint id [[vertex_id]]){float2 q=float2((id<<1)&2,id&2);return {float4(q*float2(2,-2)+float2(-1,1),0,1)};}
float3 demoRay(float2 pixel,constant DemoCamera&c){float2 ndc=pixel/c.viewport.zw*float2(2,-2)+float2(-1,1);float4 p=c.inverseViewProjection*float4(ndc,0,1);return normalize(p.xyz/p.w-c.eye.xyz);}
fragment ScenePixel demo_scene_fs(SceneO o [[stage_in]],constant DemoCamera&c [[buffer(1)]]){
 float3 ray=demoRay(o.p.xy,c),horizon=float3(.68f,.77f,.85f),zenith=float3(.38f,.58f,.80f);
 float3 sky=mix(horizon,zenith,smoothstep(-.03f,.55f,ray.y));
 float clouds=shipFireTurbulence(ray*7.f+float3(0,1.7f,0));sky+=float3(.045f)*smoothstep(.58f,.78f,clouds)*smoothstep(.06f,.32f,ray.y);
 if(ray.y>=-.0001f)return {float4(sky,1),1};
 float distance=(-.35f-c.eye.y)/ray.y;float3 p=c.eye.xyz+ray*distance;
 float2 wave=p.xz*.16f;float time=c.time.x;
 float a=sin(wave.x*.87f+wave.y*.39f-time*.8f),b=sin(wave.y*1.13f-wave.x*.33f+time*.6f);
 float3 normal=normalize(float3(-a*.14f,1,-b*.12f));float fresnel=pow(1.f-saturate(dot(normal,-ray)),4.f);
 float sheen=pow(max(dot(normal,normalize(-ray+normalize(c.sun.xyz))),0.f),100.f);
 float3 water=mix(float3(.34f,.52f,.61f),horizon*.85f,fresnel)+sheen*float3(.35f,.31f,.21f);
 water+=float3(.025f,.03f,.033f)*(a*.5f+b*.5f);
 float haze=1.f-exp(-distance*.0008f);water=mix(water,horizon,haze);
 float4 clip=c.viewProjection*float4(p,1);float depth=clamp(clip.z/clip.w,0.f,1.f);
 return {float4(water,1),depth};
}
struct TerrainV {packed_float3 p,n;};
struct TerrainO {float4 p [[position]];float3 normal,world;};
vertex TerrainO terrain_vs(uint id [[vertex_id]],const device TerrainV*vertices [[buffer(0)]],constant DemoCamera&c [[buffer(1)]]) {
 TerrainV v=vertices[id];return {c.viewProjection*float4(v.p,1),float3(v.n),float3(v.p)};
}
fragment float4 terrain_fs(TerrainO v [[stage_in]]) {
 float3 n=normalize(v.normal);float light=.40f+.60f*max(0.f,dot(n,normalize(float3(-.48f,.81f,-.32f))));
 float3 stone=mix(float3(.42f,.36f,.24f),float3(.29f,.37f,.22f),smoothstep(8.f,120.f,v.world.y)*n.y);
 return float4(stone*light,1);
}
)MSL";
simd_float4x4 lookAt(simd_float3 eye,simd_float3 target){
 auto z=simd_normalize(target-eye),x=simd_normalize(simd_cross(simd_make_float3(0,1,0),z)),y=simd_cross(z,x);
 return (simd_float4x4){{{x.x,y.x,z.x,0},{x.y,y.y,z.y,0},{x.z,y.z,z.z,0},{-simd_dot(x,eye),-simd_dot(y,eye),-simd_dot(z,eye),1}}};
}
simd_float4x4 perspective(){float scale=1.f/std::tan(.72f*.5f),near=.3f,far=32000.f;return (simd_float4x4){{{scale/(float(width)/height),0,0,0},{0,scale,0,0},{0,0,far/(far-near),1},{0,0,-near*far/(far-near),0}}};}
void savePNG(id<MTLTexture>texture,NSString*path){
 NSBitmapImageRep*image=[[NSBitmapImageRep alloc] initWithBitmapDataPlanes:nullptr pixelsWide:width pixelsHigh:height bitsPerSample:8 samplesPerPixel:4 hasAlpha:YES isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bitmapFormat:0 bytesPerRow:width*4 bitsPerPixel:32];
 std::vector<uint8_t>bgra(size_t(width)*height*4);[texture getBytes:bgra.data() bytesPerRow:width*4 fromRegion:MTLRegionMake2D(0,0,width,height) mipmapLevel:0];auto*rgba=image.bitmapData;
 for(size_t i=0;i<bgra.size();i+=4){rgba[i]=bgra[i+2];rgba[i+1]=bgra[i+1];rgba[i+2]=bgra[i];rgba[i+3]=255;}
 NSData*png=[image representationUsingType:NSBitmapImageFileTypePNG properties:@{}];if(![png writeToFile:path atomically:YES])throw std::runtime_error("Cannot save rendered PNG");
}

int main(int argc,char**argv){@autoreleasepool{try{
 auto device=MTLCreateSystemDefaultDevice();auto queue=[device newCommandQueue];NSError *error=nil;
 auto library=[device newLibraryWithSource:@((std::string(storm_metal::shipFireCommonMSL)+sceneMSL).c_str()) options:nil error:&error];if(!library)throw std::runtime_error(error.localizedDescription.UTF8String);
 auto pd=[MTLRenderPipelineDescriptor new];pd.vertexFunction=[library newFunctionWithName:@"demo_scene_vs"];pd.fragmentFunction=[library newFunctionWithName:@"demo_scene_fs"];pd.colorAttachments[0].pixelFormat=MTLPixelFormatBGRA8Unorm;pd.depthAttachmentPixelFormat=MTLPixelFormatDepth32Float;
 auto pipeline=[device newRenderPipelineStateWithDescriptor:pd error:&error];if(!pipeline)throw std::runtime_error(error.localizedDescription.UTF8String);
 auto td=[MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm width:width height:height mipmapped:NO];td.storageMode=MTLStorageModeShared;td.usage=MTLTextureUsageRenderTarget|MTLTextureUsageShaderRead;auto color=[device newTextureWithDescriptor:td];td.pixelFormat=MTLPixelFormatDepth32Float;td.storageMode=MTLStorageModePrivate;auto depth=[device newTextureWithDescriptor:td];
 auto dd=[MTLDepthStencilDescriptor new];dd.depthCompareFunction=MTLCompareFunctionAlways;dd.depthWriteEnabled=YES;auto ds=[device newDepthStencilStateWithDescriptor:dd];
 pd.vertexFunction=[library newFunctionWithName:@"terrain_vs"];pd.fragmentFunction=[library newFunctionWithName:@"terrain_fs"];
 auto terrainPipeline=[device newRenderPipelineStateWithDescriptor:pd error:&error];if(!terrainPipeline)throw std::runtime_error(error.localizedDescription.UTF8String);
 dd.depthCompareFunction=MTLCompareFunctionLess;auto terrainDepth=[device newDepthStencilStateWithDescriptor:dd];
 struct Vertex {float p[3],n[3];};std::vector<Vertex> vertices;
 auto terrain=[](float x,float z){float a=(x-900.f)/580.f,b=z/590.f,c=(x-550.f)/350.f,d=(z+270.f)/350.f;return 340.f*std::exp(-a*a-b*b)+130.f*std::exp(-c*c-d*d)-9.f;};
 for(unsigned z=0;z<80;++z)for(unsigned x=0;x<80;++x)for(unsigned i:{0u,1u,2u,2u,1u,3u}) {
  float px=-500.f+(x+(i&1))*2600.f/80.f,pz=-1100.f+(z+(i>>1))*2200.f/80.f;
  auto n=simd_normalize(simd_make_float3(terrain(px-1,pz)-terrain(px+1,pz),2.f,terrain(px,pz-1)-terrain(px,pz+1)));
  vertices.push_back({{px,terrain(px,pz),pz},{n.x,n.y,n.z}});
 }
 auto terrainBuffer=[device newBufferWithBytes:vertices.data() length:vertices.size()*sizeof(Vertex) options:MTLResourceStorageModeShared];
 storm_metal::PhonkNuclearRenderer nuclear;
 for(unsigned camera=0;camera<3;++camera)for(unsigned frame=0;frame<120;++frame){
 float age=camera==0?2.5f:1.5f+float(frame)/60.f;
  auto eye=simd_make_float3(1700.f+(camera!=1?float(frame)*.02f:0.f),camera==2?950.f:450.f,camera==2?6000.f:3000.f);auto view=lookAt(eye,simd_make_float3(600.f,80.f,0.f)),projection=perspective();
  DemoCamera c{};c.viewProjection=simd_mul(projection,view);c.inverseViewProjection=simd_inverse(c.viewProjection);c.eye=simd_make_float4(eye,1);c.viewport={0,0,width,height};c.sun={-.48f,.81f,-.32f,0};c.time.x=age;
  std::vector<double> times;
  for(unsigned repeat=0;repeat<1;repeat++){
   auto command=[queue commandBuffer];auto pass=[MTLRenderPassDescriptor renderPassDescriptor];pass.colorAttachments[0].texture=color;pass.colorAttachments[0].loadAction=MTLLoadActionClear;pass.colorAttachments[0].storeAction=MTLStoreActionStore;pass.depthAttachment.texture=depth;pass.depthAttachment.loadAction=MTLLoadActionClear;pass.depthAttachment.storeAction=MTLStoreActionStore;pass.depthAttachment.clearDepth=1;
   auto encoder=[command renderCommandEncoderWithDescriptor:pass];[encoder setRenderPipelineState:pipeline];[encoder setDepthStencilState:ds];[encoder setFragmentBytes:&c length:sizeof(c) atIndex:1];[encoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];
   [encoder setRenderPipelineState:terrainPipeline];[encoder setDepthStencilState:terrainDepth];[encoder setCullMode:MTLCullModeNone];
   [encoder setVertexBuffer:terrainBuffer offset:0 atIndex:0];[encoder setVertexBytes:&c length:sizeof(c) atIndex:1];
   [encoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:vertices.size()];[encoder endEncoding];
   const float center[]={0,0,0};auto rebasedView=lookAt(simd_make_float3(0.f,0.f,0.f),simd_make_float3(600.f,80.f,0.f)-eye);if(!nuclear.encode(device,command,color,depth,rebasedView,projection,-eye,{0,0,width,height},center,220.f*std::strtof(argv[3],nullptr),age,1.f,2500.f*std::strtof(argv[3],nullptr)*std::min(1.f,age/8.f),8.f))throw std::runtime_error("encode failed");
   [command commit];[command waitUntilCompleted];if(command.status!=MTLCommandBufferStatusCompleted)throw std::runtime_error("GPU failed");if(repeat>=0)times.push_back((command.GPUEndTime-command.GPUStartTime)*1000.);
  }
  static std::vector<uint8_t> previous;static double meanSum=0,maxMean=0;static unsigned changedSum=0;
  std::vector<uint8_t> pixels(size_t(width)*height*4);[color getBytes:pixels.data() bytesPerRow:width*4 fromRegion:MTLRegionMake2D(0,0,width,height) mipmapLevel:0];
  if(frame){double sum=0;unsigned changed=0;for(size_t i=0;i<pixels.size();i+=4){unsigned d=0;for(unsigned c=0;c<3;c++)d+=std::abs(int(pixels[i+c])-int(previous[i+c]));sum+=d;changed+=d>60;}double mean=sum/(width*height*3);meanSum+=mean;maxMean=std::max(maxMean,mean);changedSum+=changed;}
  previous=pixels;
  if(frame==119){printf("mode=%u frames=120 fps=60 meanFrameDelta=%.6f maxFrameDelta=%.6f jumpingPixels=%.3f\n",camera,meanSum/119,maxMean,double(changedSum)/119);meanSum=0;maxMean=0;changedSum=0;}
  savePNG(color,[NSString stringWithFormat:@"%s/%s-m%u-f%03u.png",argv[1],argv[2],camera,frame]);
 }
 return 0;
}catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}}}
